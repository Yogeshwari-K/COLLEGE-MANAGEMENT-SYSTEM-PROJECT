package newpackage;

public class GrUser {
private int id;
private String reg;
private String name,dob,degree,dep,sem,em,ep,ec,eg,ce,es,tm,per,re;
public GrUser()
{
	
}
public GrUser(int id, String reg, String name, String dob, String degree, String dep, String sem, String em, String ep,
		String ec, String eg, String ce, String es, String tm, String per, String re) {
	super();
	this.id = id;
	this.reg = reg;
	this.name = name;
	this.dob = dob;
	this.degree = degree;
	this.dep = dep;
	this.sem = sem;
	this.em = em;
	this.ep = ep;
	this.ec = ec;
	this.eg = eg;
	this.ce = ce;
	this.es = es;
	this.tm = tm;
	this.per = per;
	this.re = re;
}
public GrUser(String reg, String name, String dob, String degree, String dep, String sem, String em, String ep,
		String ec, String eg, String ce, String es, String tm, String per, String re) {
	super();
	this.reg = reg;
	this.name = name;
	this.dob = dob;
	this.degree = degree;
	this.dep = dep;
	this.sem = sem;
	this.em = em;
	this.ep = ep;
	this.ec = ec;
	this.eg = eg;
	this.ce = ce;
	this.es = es;
	this.tm = tm;
	this.per = per;
	this.re = re;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getReg() {
	return reg;
}
public void setReg(String reg) {
	this.reg = reg;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getDegree() {
	return degree;
}
public void setDegree(String degree) {
	this.degree = degree;
}
public String getDep() {
	return dep;
}
public void setDep(String dep) {
	this.dep = dep;
}
public String getSem() {
	return sem;
}
public void setSem(String sem) {
	this.sem = sem;
}
public String getEm() {
	return em;
}
public void setEm(String em) {
	this.em = em;
}
public String getEp() {
	return ep;
}
public void setEp(String ep) {
	this.ep = ep;
}
public String getEc() {
	return ec;
}
public void setEc(String ec) {
	this.ec = ec;
}
public String getEg() {
	return eg;
}
public void setEg(String eg) {
	this.eg = eg;
}
public String getCe() {
	return ce;
}
public void setCe(String ce) {
	this.ce = ce;
}
public String getEs() {
	return es;
}
public void setEs(String es) {
	this.es = es;
}
public String getTm() {
	return tm;
}
public void setTm(String tm) {
	this.tm = tm;
}
public String getPer() {
	return per;
}
public void setPer(String per) {
	this.per = per;
}
public String getRe() {
	return re;
}
public void setRe(String re) {
	this.re = re;
}

}
