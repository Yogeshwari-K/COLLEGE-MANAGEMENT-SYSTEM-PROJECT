package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addattendanceServlet")
public class addattendanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String date=request.getParameter("date");
		String name = request.getParameter("name");
		String degree = request.getParameter("degree");
		String dep = request.getParameter("dep");
		String sem = request.getParameter("sem");
		String attend = request.getParameter("attend");
		String si = request.getParameter("si");
		
		
		AtUser userModel = new AtUser(date,name, degree, dep, sem, attend,si);
		// create a database model
		AtUserdatabase regUser = new AtUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
			response.sendRedirect("atindex.html");
		} else {
			String errorMessage = "User Available";
			HttpSession regSession = request.getSession();
			regSession.setAttribute("RegError", errorMessage);
			response.sendRedirect("ateregisterationerror.jsp");
		}
	}

}
