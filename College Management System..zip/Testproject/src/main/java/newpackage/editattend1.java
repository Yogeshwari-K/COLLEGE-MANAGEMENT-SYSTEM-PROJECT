package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editattend1")
public class editattend1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String date=request.getParameter("date");
		String name = request.getParameter("name");
		String degree = request.getParameter("degree");
		String  dep= request.getParameter("dep");
		String sem=request.getParameter("sem");
		String attend = request.getParameter("attend");
		String  si = request.getParameter("si");
       
      
		AtUser e = new AtUser();
		e.setId(id);
		e.setDate(date);
		e.setName(name);
		e.setDegree(degree);
		e.setDep(dep);
		e.setSem(sem);
		e.setAttend(attend);
		e.setSi(si);
		int status = AtUserdatabase.atupdate(e);
		if (status > 0) {
			response.sendRedirect("viewattendance");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
		
	}

}
