package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ugeditServlet1")
public class ugeditServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String dob=request.getParameter("dob");
		String gender=request.getParameter("gender");
		String hscp=request.getParameter("hscp");
		String sslcp=request.getParameter("sslcp");
		String degree = request.getParameter("degree");
		String dep = request.getParameter("dep");
		String email = request.getParameter("email");
		String phone=request.getParameter("phone");
		String hscg=request.getParameter("hscg");
		String city=request.getParameter("city");
		
		UgUser e = new UgUser();
		e.setId(id);
		e.setFname(fname);
		e.setLname(lname);
		e.setDob(dob);
		e.setGender(gender);
		e.setHscp(hscp);
		e.setSslcp(sslcp);
		e.setDegree(degree);
		e.setDep(dep);
		e.setEmail(email);
		e.setPhone(phone);
		e.setHscg(hscg);
		e.setCity(city);
		
		
		int status = UgUserdatabase.update(e);
		if (status > 0) {
			response.sendRedirect("viewugadmissionServlet");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
