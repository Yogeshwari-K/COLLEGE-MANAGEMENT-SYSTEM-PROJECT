package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editfees")
public class editfees extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Fees</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		FeUser e = FeUserdatabase.fegetEmployeeById(id);
		out.print("<form action='editfees1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
		out.print("<tr><td>Year:</td><td><input type='text' name='year' value='" + e.getYear() + "'/></td></tr>");
		out.print("<tr><td>Tution Fees:</td><td><input type='text' name='tution' value='" + e.getTution()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Placement Fees:</td><td><input type='text' name='place' value='" + e.getPlace() + "'/></td></tr>");
		out.print("<tr><td>Hostel Fees:</td><td><input type='text' name='hostel' value='" + e.getHostel() + "'/></td></tr>");
		out.print("<tr><td>Mess Fees:</td><td><input type='text' name='mess' value='" + e.getMess() + "'/></td></tr>");
		out.print("<tr><td>Other Fees:</td><td><input type='text' name='other' value='" + e.getOther() + "'/></td></tr>");
		out.print("<tr><td>Total Fees(Non-Hosteller):</td><td><input type='text' name='total' value='" + e.getTotal() + "'/></td></tr>");
		out.print("<tr><td>Total Fees(Hosteller):</td><td><input type='text' name='totalh' value='" + e.getTotalh() + "'/></td></tr>");
		
		
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
	}

	}


