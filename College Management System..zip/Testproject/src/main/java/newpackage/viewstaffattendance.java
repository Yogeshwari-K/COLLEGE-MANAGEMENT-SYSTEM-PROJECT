package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewstaffattendance")
public class viewstaffattendance extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='staffattendance.jsp'>Mark Attendance</a>");
		out.println("<br>");
		out.println("<a href='staffdash.jsp'>Back to Dashboard</a>");
		out.println("<h1>Attendance </h1>");
		List<StaffUser> list = StaffUserdatabase.getAllEmployees();
		out.print("<table border='1' width='100%'");
		out.print(
				"<tr><th>ID</th><th>DATE</th><th>NANE</th><th>DEPARTMENT</th><th>ATTENDANCE</th><th>EDIT</th><th>DELETE</th></tr>");
		for (StaffUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getDate() + "</td><td>" + u.getName() + "</td><td>"
					+ u.getDep() + "</td><td>" + u.getAttend()  
					+ "</td><td><a href='editstaffattend?id=" + u.getId()
					+ "'>edit</a></td><td><a href='deletestaffattend?id=" + u.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");

		out.close();
	}

	
}
