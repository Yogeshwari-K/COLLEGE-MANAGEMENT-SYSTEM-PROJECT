package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ReUserdatabase {
	Connection con ;
    public ReUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(ReUser reuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into results(Reg_No,Name,Dob,Degree,Department,Semester,Engg_Mathematics,Engg_Physics,Engg_Chemistry,Engg_Graphics,Communicative_English,Environmental_Science,Total_Marks,Percentage,Result) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, reuser.getReg());
           pt.setString(2,reuser.getName());
           pt.setString(3,reuser.getDob());
           pt.setString(4, reuser.getDegree());
           pt.setString(5, reuser.getDep());
           pt.setString(6,reuser.getSem());
           pt.setString(7, reuser.getEm());
           pt.setString(8, reuser.getEp());
           pt.setString(9, reuser.getEc());
           pt.setString(10, reuser.getEg());
           pt.setString(11, reuser.getCe());
           pt.setString(12, reuser.getEs());
           pt.setString(13, reuser.getTm());
           pt.setString(14, reuser.getPer());
           pt.setString(15,reuser.getRe());
           
           
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    //user login
    public ReUser rlogUser(String reg, String dob){
        
    	ReUser rusr=null;
        try{
            String query ="select * from results where Reg_No=? and Dob=?";
            PreparedStatement rpst = this.con.prepareStatement(query);
            rpst.setString(1, reg);
            rpst.setString(2, dob);
            
            ResultSet rrs = rpst.executeQuery();
            if(rrs.next()){
            	
                rusr = new ReUser();
                rusr.setId(rrs.getInt("id"));
                rusr.setReg(rrs.getString("reg"));
                rusr.setName(rrs.getString("name"));
               rusr.setDob(rrs.getString("dob"));
               rusr.setDegree(rrs.getString("degree"));
                rusr.setDep(rrs.getString("dep"));
                rusr.setSem(rrs.getString("sem"));
                rusr.setEm(rrs.getString("em"));
                rusr.setEp(rrs.getString("ep"));
                rusr.setEc(rrs.getString("ec"));
                rusr.setEg(rrs.getString("eg"));
                rusr.setCe(rrs.getString("ce"));
                rusr.setEs(rrs.getString("es"));
                rusr.setTm(rrs.getString("tm"));
                rusr.setPer(rrs.getString("per"));
                rusr.setRe(rrs.getString("re"));
                 
                
            }
            
        }catch(Exception e)
        {
        	e.printStackTrace();
        }
		return rusr;
       
    }
    
    public static int rupdate(ReUser e) {
		int status = 0;
		try {
			Connection con =ReUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update results set Reg_No=?,Name=?,Dob=?,Degree=?,Department=?,Semester=?,Engg_Mathematics=?,Engg_Physics=?,Engg_Chemistry=?,Engg_Graphics=?,Communicative_English=?,Environmental_Science=?,Total_Marks=?,Percentage=?,Result=? where Id=?");
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getReg());
			ps.setString(2, e.getName());
			ps.setString(3, e.getDob());
			ps.setString(4, e.getDegree());
			ps.setString(5, e.getDep());
			ps.setString(6, e.getSem());	
			ps.setString(7,e.getEm());
			ps.setString(8, e.getEp());
			ps.setString(9, e.getEc());
			ps.setString(10, e.getEg());	
			ps.setString(11,e.getCe());
			ps.setString(12, e.getEs());
			ps.setString(13, e.getTm());
			ps.setString(14, e.getPer());	
			ps.setString(15,e.getRe());
			ps.setInt(16, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int rdelete(int id){  
        int status=0;  
        try{  
            Connection con=ReUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from results where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  ReUser getEmployeeById(int id) {
		ReUser u = new ReUser();

		try {
			Connection con = ReUserdatabase.getConnection();
			String query ="select * from results where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
                u.setReg(rs.getString(2));
                u.setName(rs.getString(3));
               u.setDob(rs.getString(4));
               u.setDegree(rs.getString(5));
                u.setDep(rs.getString(6));
               u.setSem(rs.getString(7));
                u.setEm(rs.getString(8));
                u.setEp(rs.getString(9));
                u.setEc(rs.getString(10));
                u.setEg(rs.getString(11));
                u.setCe(rs.getString(12));
                u.setEs(rs.getString(13));
                u.setTm(rs.getString(14));
                u.setPer(rs.getString(15));
                u.setRe(rs.getString(16));
                 
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}

	public static  List<ReUser> getAllEmployees() {
		List<ReUser> list = new ArrayList<ReUser>();

		try {
			Connection con = ReUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from results");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ReUser u = new ReUser(); 
				 u.setId(rs.getInt(1));  
				u.setReg(rs.getString(2));
				u.setName(rs.getString(3));
				u.setDob(rs.getString(4));
				u.setDegree(rs.getString(5));
				u.setDep(rs.getString(6));
				u.setSem(rs.getString(7));
				u.setEm(rs.getString(8));
				u.setEp(rs.getString(9));
				u.setEc(rs.getString(10));
				u.setEg(rs.getString(11));
				u.setCe(rs.getString(12));
				u.setEs(rs.getString(13));
				u.setTm(rs.getString(14));
				u.setPer(rs.getString(15));
				u.setRe(rs.getString(16));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
	public static List<ReUser> getresult(String reg,String dob) {
		// TODO Auto-generated method stub
		List<ReUser> list = new ArrayList<ReUser>();
		try {
			Connection con = ReUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from results where Reg_No=? and Dob=?");
			 ps.setString(1, reg);
	            ps.setString(2, dob);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ReUser u = new ReUser(); 
				 u.setId(rs.getInt(1));  
				u.setReg(rs.getString(2));
				u.setName(rs.getString(3));
				u.setDob(rs.getString(4));
				u.setDegree(rs.getString(5));
				u.setDep(rs.getString(6));
				u.setSem(rs.getString(7));
				u.setEm(rs.getString(8));
				u.setEp(rs.getString(9));
				u.setEc(rs.getString(10));
				u.setEg(rs.getString(11));
				u.setCe(rs.getString(12));
				u.setEs(rs.getString(13));
				u.setTm(rs.getString(14));
				u.setPer(rs.getString(15));
				u.setRe(rs.getString(16));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}}
