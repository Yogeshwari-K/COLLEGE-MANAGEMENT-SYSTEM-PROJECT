package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AUserdatabase {
	Connection con ;

    public AUserdatabase(Connection con) {
        this.con = con;
    }
    public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    
	 public AUser alogUser(String name, String pass){
	        
	    	AUser ausr=null;
	        try{
	            String query ="select * from user3 where name=? and password=?";
	            PreparedStatement fpst = this.con.prepareStatement(query);
	            fpst.setString(1, name);
	            fpst.setString(2, pass);
	            
	            ResultSet ars = fpst.executeQuery();
	            
	            if(ars.next()){
	                ausr = new AUser();
	                ausr.setId(ars.getInt("id"));
	                ausr.setName(ars.getString("name"));
	                ausr.setPassword(ars.getString("password"));
	                
	            }
	            
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return ausr;
	    }
	 public static  AUser getAllEmployees(String name,String password) {
			
  AUser u=new AUser();
			try {
				Connection con = AUserdatabase.getConnection();
				String query ="select * from user3 where name=? and password=?";
	            PreparedStatement pst = con.prepareStatement(query);
	            pst.setString(1, name);
	            pst.setString(2,password);
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					
					u.setId(rs.getInt(1));
					u.setName(rs.getString(2));
					u.setPassword(rs.getString(3));
				
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return u;

}
	 public FUser flogUser(String name, String pass){
	        
	    	FUser fusr=null;
	        try{
	            String query ="select * from user2 where Username=? and password=?";
	            PreparedStatement fpst = this.con.prepareStatement(query);
	            fpst.setString(1, name);
	            fpst.setString(2, pass);
	            
	            ResultSet frs = fpst.executeQuery();
	            
	            if(frs.next()){
	                fusr = new FUser();
	                fusr.setId(frs.getInt("id"));
	                fusr.setName(frs.getString("name"));
	               fusr.setDob(frs.getString("dob"));
	               fusr.setGender(frs.getString("gender"));
	                fusr.setUsername(frs.getString("username"));
	                fusr.setEmail(frs.getString("email"));
	                fusr.setPhone(frs.getString("phone"));
	                fusr.setPassword(frs.getString("password"));
	             
	                
	            }
	            
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return fusr;
	    }
	    
	    public static int aupdate(AUser e) {
			int status = 0;
			try {
				Connection con = AUserdatabase.getConnection();
				PreparedStatement ps = con.prepareStatement(
						"update user3 set Name=?,password=? where Id=?");
				//ps.setInt(1, e.getId());
				ps.setString(1, e.getName());
				
				ps.setString(2,e.getPassword());
				ps.setInt(3, e.getId());
				status = ps.executeUpdate();
				con.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return status;
		}
	    public static  AUser getEmployeeById(int id) {
			AUser u = new AUser();

			try {
				Connection con = FUserdatabase.getConnection();
				String query ="select * from user3 where Id=?";
	            PreparedStatement pst = con.prepareStatement(query);
				pst.setInt(1, id);
				ResultSet rs = pst.executeQuery();
				if (rs.next()) { 
					u.setId(rs.getInt(1));
					u.setName(rs.getString(2));
					
					u.setPassword(rs.getString(3));
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return u;
		}
	 public static AUser get(String username) {
			AUser u = new AUser();

			try {
				Connection con = AUserdatabase.getConnection();
				String query ="select * from user3 where name=?";
	            PreparedStatement pst = con.prepareStatement(query);
				pst.setString(1, username);
				ResultSet rs = pst.executeQuery();
				if (rs.next()) { 
					u.setId(rs.getInt(1));
					u.setName(rs.getString(2));
					
					u.setPassword(rs.getString(3));
					
										
					
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return u;
}
	 public static int reupdate(AUser e) {
			int status = 0;
		
			try {
				Connection con = AUserdatabase.getConnection();
				PreparedStatement ps = con.prepareStatement(
						"update user3 set password=? where name=?");
				//ps.setInt(1, e.getId());
			
			
				ps.setString(1,e.getPassword());
				ps.setString(2, e.getName());
				status = ps.executeUpdate();
				con.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return status;
		}
	 public static  AUser getCheck(String username,String password) {

			AUser u = new AUser();

			try {
				Connection con = SaUserdatabase.getConnection();
				String query ="select * from user3 where name=? and password=?";
	            PreparedStatement pst = con.prepareStatement(query);
				pst.setString(1, username);
				pst.setString(2, password);
				ResultSet rs = pst.executeQuery();
				if (rs.next()) { 
					u.setId(rs.getInt(1));
					u.setName(rs.getString(2));
					
					u.setPassword(rs.getString(3));
					
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return u;
		}
	 }