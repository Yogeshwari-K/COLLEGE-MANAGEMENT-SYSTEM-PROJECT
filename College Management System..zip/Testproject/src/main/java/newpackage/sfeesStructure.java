package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/sfeesStructure")
public class sfeesStructure extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='sindex.html'>back</a>");
		out.println("<br><br>");
		List<FeUser> list = FeUserdatabase.getAllEmployees();
		out.println("<a href='staffdash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Fees Structure</h1>");
		
		out.print("<table border='1' width='70%'");
		out.print(
				"<tr><th>ID</th><th>YEAR</th><th>TUTION FEES</th><th>PLACEMENT FEES</th><th>HOSTEL FEES</th><th>MESS FEES</th><th>OTHER FEES</th><th>TOTAL FEES(NON-HOSTELLER)</th><th>TOTAL FEES(HOSTELLER)</th></tr>");
		for (FeUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getYear() + "</td><td>" + u.getTution() + "</td><td>"
					+ u.getPlace() + "</td><td>" + u.getHostel() + "</td><td>" + u.getMess() + "</td><td>" + u.getOther()+ "</td><td>" + u.getTotal()+ "</td><td>" + u.getTotalh()+"</th></tr>");
		}
		out.print("</table>");

		out.close();
		out.println("</div>");
	}

}
