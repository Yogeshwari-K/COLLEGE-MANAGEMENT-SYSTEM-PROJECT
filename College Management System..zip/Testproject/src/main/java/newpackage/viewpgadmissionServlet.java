package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewpgadmissionServlet")
public class viewpgadmissionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='pgapply.jsp'>Apply PG</a>");
		out.println("<br>");
		out.println("<a href='admindash.jsp'>Back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>PG Admission List</h1>");
		List<PgUser> list = PgUserdatabase.getAllEmployees();
		out.print("<table border='1' width='80%'");
		out.print(
				"<tr><th>ID</th><th>FULL NAME</th><th>LAST NAME</th><th>DOB</th><th>GENDER</th><th>HSC %</th><th>SSLC %</th><th>DEGREE</th><th>DEPARTMENT</th><th>EMAIL</th><th>PHONE</th><th>UG %</th><th>CITY</th><th>EDIT</th><th>DELETE</th></tr>");
		for (PgUser u : list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getFname() + "</td><td>" + u.getLname() + "</td><td>"
					+ u.getDob() + "</td><td>" + u.getGender() + "</td><td>" + u.getHscp() + "</td><td>" + u.getSslcp()
					+ "</td><td>" + u.getDegree() + "</td><td>" + u.getDep() + "</td><td>" + u.getEmail() + "</td><td>"
					+ u.getPhone() +"</td><td>"	 + u.getUgp() + "</td><td>" + u.getCity() +"</td><td><a href='pgeditServlet?id="
							+ u.getId() +"'>edit</a></td><td><a href='pgdeleteServlet?id=" + u.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}
	

}
