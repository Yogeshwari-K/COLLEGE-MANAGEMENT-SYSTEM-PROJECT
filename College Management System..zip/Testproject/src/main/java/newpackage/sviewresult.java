package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/sviewresult")
public class sviewresult extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='staffsturesult.jsp'>Get Result</a>");
		out.println("<br>");
		out.println("<a href='staffdash.jsp'>Back to Dashboard</a>");
		out.println("<h1>Results List</h1>");
		List<ReUser> list = ReUserdatabase.getAllEmployees();
		out.print("<table border='1' width='100%'");
		out.print(
				"<tr><th>ID</th><th>REGISTER NUMBER</th><th>NAME</th><th>DOB</th><th>DEGREE</th><th>DEPARTMENT</th><th>SEMESTER</th><th>ENGINEERING MATHS</th><th>ENGINEERING PHYSICS</th><th>ENGINEERING CHEMISTRY</th><th>ENGINEERING GRAPHICS</th><th>COMMUNICATION ENGLISH</th><th>ENVIRONMENTAL SCIENCE</th><th>TOTAL MARKS</th><th>PERCENTAGE</th><th>RESULT</th></tr>");
		for (ReUser u : list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getReg() + "</td><td>" + u.getName() + "</td><td>"
					+ u.getDob() + "</td><td>" + u.getDegree() + "</td><td>" + u.getDep() + "</td><td>" + u.getSem()
					+ "</td><td>" + u.getEm() + "</td><td>" + u.getEp() + "</td><td>" + u.getEc() + "</td><td>"
					+ u.getEg() + "</td><td>" + u.getCe() + "</td><td>" + u.getEs() + "</td><td>" + u.getTm()
					+ "</td><td>" + u.getPer() + "</td><td>" + u.getRe() + "</td></tr>");
		}
		out.print("</table>");

		out.close();
	}

	

}
