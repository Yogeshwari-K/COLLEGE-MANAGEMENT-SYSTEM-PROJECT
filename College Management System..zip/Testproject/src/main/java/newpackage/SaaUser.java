package newpackage;

public class SaaUser {
private int id;
private String name,dob,desig,date;
private double inc,sal,pd,ba;
public SaaUser()
{
	
}
public SaaUser(int id, String name, String dob, String desig, String date, double inc, double sal, double pd,
		double ba) {
	super();
	this.id = id;
	this.name = name;
	this.dob = dob;
	this.desig = desig;
	this.date = date;
	this.inc = inc;
	this.sal = sal;
	this.pd = pd;
	this.ba = ba;
}
public SaaUser(String name, String dob, String desig,  double inc, double sal, double pd, double ba,String date) {
	super();
	this.name = name;
	this.dob = dob;
	this.desig = desig;
	this.date = date;
	this.inc = inc;
	this.sal = sal;
	this.pd = pd;
	this.ba = ba;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getDesig() {
	return desig;
}
public void setDesig(String desig) {
	this.desig = desig;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public double getInc() {
	return inc;
}
public void setInc(double inc) {
	this.inc = inc;
}
public double getSal() {
	return sal;
}
public void setSal(double sal) {
	this.sal = sal;
}
public double getPd() {
	return pd;
}
public void setPd(double pd) {
	this.pd = pd;
}
public double getBa() {
	return ba;
}
public void setBa(double ba) {
	this.ba = ba;
}

}
