package newpackage;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editfee")
public class editfee extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Fees</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		FeeUser e = FeeUserdatabase.feegetEmployeeById(id);
		out.print("<form action='editfee1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
		out.print("<tr><td>Name:</td><td><input type='text' name='name' value='" + e.getName() + "'/></td></tr>");
		out.print("<tr><td>Degree:</td><td><input type='text' name='degree' value='" + e.getDegree()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Department Fees:</td><td><input type='text' name='dep' value='" + e.getDep() + "'/></td></tr>");
		out.print("<tr><td>Semester:</td><td><input type='text' name='sem' value='" + e.getSem() + "'/></td></tr>");
		out.print("<tr><td>Hosteller(Yes/No):</td><td><input type='text' name='hosteller' value='" + e.getHosteller() + "'/></td></tr>");
		out.print("<tr><td>Total Fees:</td><td><input type='text' name='tf' value='" + e.getTf() + "'/></td></tr>");
		out.print("<tr><td>Paid:</td><td><input type='text' name='pd' value='" + e.getPd() + "'/></td></tr>");
		out.print("<tr><td>Balance:</td><td><input type='text' name='ba' value='" + e.getBa()+ "'/></td></tr>");
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
		
	}

	
}
