package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/reeditSerrvlet1")
public class reeditSerrvlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String reg=request.getParameter("reg");
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		
		String degree=request.getParameter("degree");
		String dep=request.getParameter("dep");
		String sem=request.getParameter("sem");
		String em = request.getParameter("em");
		String ep = request.getParameter("ep");
		String ec=request.getParameter("ec");
		String eg=request.getParameter("eg");
		String ce=request.getParameter("ce");
		String es=request.getParameter("es");
		String tm=request.getParameter("tm");
		String per=request.getParameter("per");
		String re=request.getParameter("re");

		ReUser e = new ReUser();
		e.setId(id);
		e.setReg(reg);
		e.setName(name);
		e.setDob(dob);
		
		e.setDegree(degree);
		e.setDep(dep);
		e.setSem(sem);
		e.setEm(em);
		e.setEp(ep);
		e.setEc(ec);
		e.setEg(eg);
		e.setCe(ce);
		e.setEs(es);
		e.setTm(tm);
		e.setPer(per);
		e.setRe(re);
		
		int status = ReUserdatabase.rupdate(e);
		if (status > 0) {
			response.sendRedirect("viewresultServlet");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
