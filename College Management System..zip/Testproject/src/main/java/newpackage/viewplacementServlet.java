package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewplacementServlet")
public class viewplacementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='placementadding.jsp'>Add New Result</a>");
		out.println("<br>");
		out.println("<a href='admindash.jsp'>Back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Placements List</h1>");
		List<PUser> list = PUserdatabase.getAllEmployees();
		out.print("<table border='1' width='70%'");
		out.print(
				"<tr><th>ID</th><th>REGISTER NUMBER</th><th>NAME</th><th>DOB</th><th>DEGREE</th><th>DEPARTMENT</th><th>YEAR OF PASSING</th><th>CGPA</th><th>COMPANY</th><th>SALARY</th><th>DESIGNATION</th><th>EDIT</th><th>DELETE</th></tr>");
		for (PUser u : list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getReg() + "</td><td>" + u.getName() + "</td><td>"
					+ u.getDob() + "</td><td>" + u.getDegree() + "</td><td>" + u.getDep() + "</td><td>" + u.getYear()
					+ "</td><td>" + u.getCgpa() + "</td><td>" + u.getCom() + "</td><td>" + u.getSal() + "</td><td>"
					+ u.getDes() + "</td><td><a href='peditServlet?id="
					+ u.getId() + "'>edit</a></td><td><a href='pdeleteServlet?id=" + u.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}
		
	}

	

