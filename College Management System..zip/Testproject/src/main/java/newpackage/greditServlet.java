package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/greditServlet")
public class greditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Details</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		GrUser rusr = GrUserdatabase.getEmployeeById(id);
		out.print("<form action='greditServlet1' method='post'>");
		out.print("<table>");
		
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+rusr.getId()+"'/></td></tr>");  
		out.print("<tr><td>Register Number:</td><td><input type='text' name='reg' value='" + rusr.getReg() + "'/></td></tr>");
		out.print("<tr><td>Name:</td><td><input type='text' name='name' value='" + rusr.getName() + "'/></td></tr>");
		out.print("<tr><td>Date of Birth:</td><td><input type='text' name='dob' value='" + rusr.getDob()	+ "'/>  </td></tr>");
		out.print("<tr><td>Degree:</td><td><input type='text' name='degree' value='" + rusr.getDegree() + "'/></td></tr>");
		out.print("<tr><td>Department:</td><td><input type='text' name='dep' value='" + rusr.getDep() + "'/></td></tr>");
		out.print("<tr><td>Semester:</td><td><input type='text' name='sem' value='" + rusr.getSem()+ "'/></td></tr>");
		out.print("<tr><td>Engineering Mathematics:</td><td><input type='text' name='em' value='" + rusr.getEm() + "'/></td></tr>");
		
		out.print("<tr><td>Engineering Physics:</td><td><input type='text' name='ep' value='" + rusr.getEp() + "'/></td></tr>");
		out.print("<tr><td>Engineering Chemistry:</td><td><input type='text' name='ec' value='" + rusr.getEc() + "'/></td></tr>");
		out.print("<tr><td>Engineering Graphics:</td><td><input type='text' name='eg' value='" + rusr.getEg() + "'/></td></tr>");
		out.print("<tr><td>Communicative English:</td><td><input type='text' name='ce' value='" + rusr.getCe() + "'/></td></tr>");
		out.print("<tr><td>Environmental Science:</td><td><input type='text' name='es' value='" + rusr.getEs() + "'/></td></tr>");
		out.print("<tr><td>Total Marks:</td><td><input type='text' name='tm' value='" + rusr.getTm() + "'/></td></tr>");
		out.print("<tr><td>Percentage:</td><td><input type='text' name='per' value='" + rusr.getPer() + "'/></td></tr>");
		out.print("<tr><td>Result:</td><td><input type='text' name='re' value='" + rusr.getRe() + "'/></td></tr>");
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
	}

	

}
