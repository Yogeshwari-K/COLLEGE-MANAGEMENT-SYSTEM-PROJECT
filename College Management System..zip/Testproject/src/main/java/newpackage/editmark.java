package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editmark")
public class editmark extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Marks</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		MUser e = MUserdatabase.mgetEmployeeById(id);
		out.print("<form action='editmark1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
		out.print("<tr><td>Name:</td><td><input type='text' name='name' value='" + e.getName() + "'/></td></tr>");
		out.print("<tr><td>Degree:</td><td><input type='text' name='degree' value='" + e.getDegree()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Department Fees:</td><td><input type='text' name='dep' value='" + e.getDep() + "'/></td></tr>");
		out.print("<tr><td>Semester:</td><td><input type='text' name='sem' value='" + e.getSem() + "'/></td></tr>");
		out.print("<tr><td>Subject Name:</td><td><input type='text' name='sub' value='" + e.getSub() + "'/></td></tr>");
		out.print("<tr><td>Total Marks:</td><td><input type='text' name='outof' value='" + e.getOutof() + "'/></td></tr>");
		out.print("<tr><td>Marks Scored:</td><td><input type='text' name='smark' value='" + e.getSmark() + "'/></td></tr>");
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
		
	}


}
