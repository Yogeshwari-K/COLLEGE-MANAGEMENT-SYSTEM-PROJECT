package newpackage;

public class TUser {
private int id;
private String sem,scode,sname,date,sess;
public TUser()
{
	
}
public TUser(String sem, String scode, String sname, String date, String sess) {
	super();
	this.sem = sem;
	this.scode = scode;
	this.sname = sname;
	this.date = date;
	this.sess = sess;
}
public TUser(int id, String sem, String scode, String sname, String date, String sess) {
	super();
	this.id = id;
	this.sem = sem;
	this.scode = scode;
	this.sname = sname;
	this.date = date;
	this.sess = sess;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getSem() {
	return sem;
}
public void setSem(String sem) {
	this.sem = sem;
}
public String getScode() {
	return scode;
}
public void setScode(String scode) {
	this.scode = scode;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getSess() {
	return sess;
}
public void setSess(String sess) {
	this.sess = sess;
}

}
