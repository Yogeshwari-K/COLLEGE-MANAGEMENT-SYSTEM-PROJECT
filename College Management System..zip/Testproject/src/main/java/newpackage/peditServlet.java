package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/peditServlet")
public class peditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Employee</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		PUser rusr = PUserdatabase.getEmployeeById(id);
		out.print("<form action='peditServlet1' method='post'>");
		out.print("<table>");
		
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+rusr.getId()+"'/></td></tr>");  
		out.print("<tr><td>Register Number:</td><td><input type='text' name='reg' value='" + rusr.getReg() + "'/></td></tr>");
		out.print("<tr><td>Name:</td><td><input type='text' name='name' value='" + rusr.getName() + "'/></td></tr>");
		out.print("<tr><td>Date of Birth:</td><td><input type='text' name='dob' value='" + rusr.getDob()	+ "'/>  </td></tr>");
		out.print("<tr><td>Degree:</td><td><input type='text' name='degree' value='" + rusr.getDegree() + "'/></td></tr>");
		out.print("<tr><td>Department:</td><td><input type='text' name='dep' value='" + rusr.getDep() + "'/></td></tr>");
		out.print("<tr><td>Year of Placing:</td><td><input type='text' name='year' value='" + rusr.getYear()+ "'/></td></tr>");
		out.print("<tr><td>CGPA:</td><td><input type='text' name='cgpa' value='" + rusr.getCgpa() + "'/></td></tr>");
		
		out.print("<tr><td>Company:</td><td><input type='text' name='com' value='" + rusr.getCom() + "'/></td></tr>");
		out.print("<tr><td>Salary(PA):</td><td><input type='text' name='sal' value='" + rusr.getSal() + "'/></td></tr>");
		out.print("<tr><td>Designation:</td><td><input type='text' name='des' value='" + rusr.getDes() + "'/></td></tr>");
		
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
	}
	}

	


