package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FeedUserdatabase {
	Connection con ;
    public FeedUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(FeedUser feeduser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into stufeed(Name,Degree,Dep,Training,Feed) values(?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, feeduser.getName());
           pt.setString(2,feeduser.getDegree());
           pt.setString(3,feeduser.getDep());
           pt.setString(4, feeduser.getTraining());
           pt.setString(5, feeduser.getFeed());
           
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int feedupdate(FeedUser e) {
		int status = 0;
		try {
			Connection con = FeedUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update stufeed set Name=?,Degree=?,Dep=?,Training=?,Feed=? where Id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getName());
			ps.setString(2, e.getDegree());
			ps.setString(3, e.getDep());
			ps.setString(4, e.getTraining());
			ps.setString(5, e.getFeed());
			
			ps.setInt(6, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int feeddelete(int id){  
        int status=0;  
        try{  
            Connection con=FeedUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from stufeed where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  FeedUser feedgetEmployeeById(int id) {
		FeedUser u = new FeedUser();

		try {
			Connection con = FUserdatabase.getConnection();
			String query ="select * from stufeed where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setTraining(rs.getString(5));
				u.setFeed(rs.getString(6));
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<FeedUser> getAllEmployees() {
		List<FeedUser> list = new ArrayList<FeedUser>();

		try {
			Connection con = FacUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from stufeed");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				FeedUser u = new FeedUser(); 
				 u.setId(rs.getInt(1));  
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setTraining(rs.getString(5));
				u.setFeed(rs.getString(6));
				
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;

	}
}