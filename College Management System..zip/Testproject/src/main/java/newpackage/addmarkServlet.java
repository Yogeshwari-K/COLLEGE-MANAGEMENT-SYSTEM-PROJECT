package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addmarkServlet")
public class addmarkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String degree=request.getParameter("degree");
		String dep=request.getParameter("dep");
		String sem = request.getParameter("sem");
		String sub = request.getParameter("sub");
		String outof=request.getParameter("outof");
		String smark=request.getParameter("smark");
		MUser userModel = new MUser(name,degree,dep,sem,sub,outof,smark);
		

		//create a database model
		MUserdatabase regUser = new MUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
		   response.sendRedirect("mindex.html");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("mregisterationerror.html");
		    }	
	}

}
