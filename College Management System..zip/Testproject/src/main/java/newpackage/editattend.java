package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editattend")
public class editattend extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Attendance</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		AtUser e = AtUserdatabase.atgetEmployeeById(id);
		out.print("<form action='editattend1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
		out.print("<tr><td>Date:</td><td><input type='text' name='date' value='" + e.getDate() + "'/></td></tr>");
		out.print("<tr><td>Name:</td><td><input type='text' name='name' value='" + e.getName() + "'/></td></tr>");
		out.print("<tr><td>Degree:</td><td><input type='text' name='degree' value='" + e.getDegree()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Department Fees:</td><td><input type='text' name='dep' value='" + e.getDep() + "'/></td></tr>");
		out.print("<tr><td>Semester:</td><td><input type='text' name='sem' value='" + e.getSem() + "'/></td></tr>");
		out.print("<tr><td>Attendance:</td><td><input type='text' name='attend' value='" + e.getAttend() + "'/></td></tr>");
		out.print("<tr><td>Staff Incharge:</td><td><input type='text' name='si' value='" + e.getSi() + "'/></td></tr>");
		
		
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
		
	}


}
