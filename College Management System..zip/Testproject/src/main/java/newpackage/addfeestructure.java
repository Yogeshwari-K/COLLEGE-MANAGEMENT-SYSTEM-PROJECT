package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addfeestructure")
public class addfeestructure extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String year = request.getParameter("year");
		String tution=request.getParameter("tution");
		String place=request.getParameter("place");
		String hostel = request.getParameter("hostel");
		String mess = request.getParameter("mess");
		String other=request.getParameter("other");
		Float year1=Float.parseFloat(year);
		Float tution1=Float.parseFloat(tution);
		Float place1=Float.parseFloat(place);
		Float hostel1=Float.parseFloat(hostel);
		Float mess1=Float.parseFloat(mess);
		Float other1=Float.parseFloat(other);
	    double total=(tution1+place1+hostel1+mess1+other1);
		//double total=Float.toString(total1);
		double totalh=(tution1+place1+other1);
		//String totalh=Float.toString(total2);
		//make user object
		FeUser userModel = new FeUser(year,tution,place,hostel,mess,other,totalh,total);
		

		//create a database model
		FeUserdatabase regUser = new FeUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
		   response.sendRedirect("feindex.html");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("feregisterationerror.html");
		    }
	}

}
