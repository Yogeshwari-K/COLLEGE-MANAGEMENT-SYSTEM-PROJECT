package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editsaal")
public class editsaal extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
	out.println("<h1>Update Salary</h1>");
	String sid = request.getParameter("id");
	int id=Integer.parseInt(sid);
	SaaUser e = SaaUserdatabase.saagetEmployeeById(id);
	out.print("<form action='editSaal1' method='post'>");
	out.print("<table>");
	out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
	out.print("<tr><td>Name:</td><td><input type='text' name='name' value='" + e.getName() + "'/></td></tr>");
	out.print("<tr><td>DOB:</td><td><input type='text' name='dob' value='" + e.getDob()
			+ "'/>  </td></tr>");
	out.print("<tr><td>Designation:</td><td><input type='text' name='desig' value='" + e.getDesig() + "'/></td></tr>");
	out.print("<tr><td>Increment:</td><td><input type='text' name='inc' value='" + e.getInc() + "'/></td></tr>");
	out.print("<tr><td>Salary:</td><td><input type='text' name='sal' value='" + e.getSal() + "'/></td></tr>");
	out.print("<tr><td>Paid:</td><td><input type='text' name='pd' value='" + e.getPd() + "'/></td></tr>");
	out.print("<tr><td>Balance</td><td><input type='text' name='ba' value='" + e.getBa() + "'/></td></tr>");
	out.print("<tr><td>Date of Issuing</td><td><input type='text' name='date' value='" + e.getDate()+ "'/></td></tr>");
	out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
	out.print("</table>");
	out.print("</form>");

	out.close();}
	
	

}
