package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/sturesultServlet")
public class sturesultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated metdoGet(request, response);
		try (PrintWriter out = response.getWriter()) {
			String reg = request.getParameter("reg");
			String dob = request.getParameter("dob");

			ReUserdatabase db = new ReUserdatabase(ConnectionPro.getConnection());
			ReUser r = db.rlogUser(reg, dob);

			if (r != null) {

				out.println("<a href='studentdash.jsp'>Back to Dashboard</a>");
				out.println("<div align='center'>");
				out.println("<h1>Your Results </h1>");
				List<ReUser> list = ReUserdatabase.getresult(reg, dob);
				out.print("<table border='1' width='30%'");
				// out.print(
				// "<td><th>ID</th><th>REGISTER
				// NUMBER</th><th>NAME</th><th>DOB</th><th>DEGREE</th><th>DEPARTMENT</th><th>SEMESTER</th><th>ENGINEERING
				// MATHS</th><th>ENGINEERING PHYSICS</th><th>ENGINEERING
				// CHEMISTRY</th><th>ENGINEERING GRAPHICS</th><th>COMMUNICATION
				// ENGLISH</th><th>ENVIRONMENTAL SCIENCE</th><th>TOTAL
				// MARKS</th><th>PERCENTAGE</th><th>RESULT</th></td>");
				// out.print("<td><th></th><th></th></td>");
				for (ReUser u : list) {
					/*
					 * out.print("</tr><td>" + u.getId() + "</td><td>" + u.getReg() + "</td><td>" +
					 * u.getName() + "</td><td>" + u.getDob() + "</td><td>" + u.getDegree() +
					 * "</td><td>" + u.getDep() + "</td><td>" + u.getSem() + "</td><td>" + u.getEm()
					 * + "</td><td>" + u.getEp() + "</td><td>" + u.getEc() + "</td><td>" + u.getEg()
					 * + "</td><td>" + u.getCe() + "</td><td>" + u.getEs() + "</td><td>" + u.getTm()
					 * + "</td><td>" + u.getPer() + "</td><td>" + u.getRe() + " </td></tr>");
					 */
					out.print("<tr><td>ID</td><td>" + u.getId() + "</td></tr><tr><td>REGISTER NUMBER</td><td> "
							+ u.getReg() + "</td></tr><tr><td>NAME</td><td>" + u.getName()
							+ "</td></tr><tr><td>DOB</td><td>" + u.getDob() + "</td></tr><tr><td>DEGREE</td><td>"
							+ u.getDegree() + "</td></tr><tr><td>DEPARTMENT</td><td>" + u.getDep()
							+ "</td></tr><tr><td>SEMESTER</td><td>" + u.getSem()
							+ "</td></tr><tr><td>ENGINEERING MATHS</td><td>" + u.getEm()
							+ "</td></tr><tr><td>ENGINEERING PHYSICS</td><td>" + u.getEp()
							+ "</td></tr><tr><td>ENGINEERING CHEMISTRY</td><td>" + u.getEc()
							+ "</td></tr><tr><td>ENGINEERING GRAPHICS</td><td>" + u.getEg()
							+ "</td></tr><tr><td>COMMUNICATION ENGLISH</td><td>" + u.getCe()
							+ "</td></tr><tr><td>ENVIRONMENTAL SCIENCE</td><td>" + u.getEs()
							+ "</td></tr><tr><td>TOTAL MARKS</td><td>" + u.getTm()
							+ "</td></tr><tr><td>PERCENTAGE</td><td>" + u.getPer()
							+ "</td></tr><tr><td>RESULTS</td><td>" + u.getRe() + "</td></tr><tr>");

				}
				out.print("</table>");

				out.close();
				out.print("</div>");

			} else {

				response.sendRedirect("rusernotfound.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}