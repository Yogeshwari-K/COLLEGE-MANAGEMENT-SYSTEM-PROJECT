package newpackage;

public class PUser {
 private int id;
 private String reg,name,dob,degree,dep,year,cgpa,com,sal,des;
 public PUser()
 {
	 
 }
public PUser(int id, String reg, String name, String dob, String degree, String dep, String year, String cgpa,
		String com, String sal, String des) {
	super();
	this.id = id;
	this.reg = reg;
	this.name = name;
	this.dob = dob;
	this.degree = degree;
	this.dep = dep;
	this.year = year;
	this.cgpa = cgpa;
	this.com = com;
	this.sal = sal;
	this.des = des;
}
public PUser(String reg, String name, String dob, String degree, String dep, String year, String cgpa, String com,
		String sal, String des) {
	super();
	this.reg = reg;
	this.name = name;
	this.dob = dob;
	this.degree = degree;
	this.dep = dep;
	this.year = year;
	this.cgpa = cgpa;
	this.com = com;
	this.sal = sal;
	this.des = des;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getReg() {
	return reg;
}
public void setReg(String reg) {
	this.reg = reg;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getDegree() {
	return degree;
}
public void setDegree(String degree) {
	this.degree = degree;
}
public String getDep() {
	return dep;
}
public void setDep(String dep) {
	this.dep = dep;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getCgpa() {
	return cgpa;
}
public void setCgpa(String cgpa) {
	this.cgpa = cgpa;
}
public String getCom() {
	return com;
}
public void setCom(String com) {
	this.com = com;
}
public String getSal() {
	return sal;
}
public void setSal(String sal) {
	this.sal = sal;
}
public String getDes() {
	return des;
}
public void setDes(String des) {
	this.des = des;
}

 
}
