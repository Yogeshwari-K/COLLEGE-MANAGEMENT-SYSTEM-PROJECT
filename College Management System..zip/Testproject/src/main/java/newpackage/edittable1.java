package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/edittable1")
public class edittable1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String sem = request.getParameter("sem");
		String scode = request.getParameter("scode");
		String  sname= request.getParameter("sname");
		String date=request.getParameter("date");
		String sess = request.getParameter("sess");
		
		TUser e = new TUser();
		e.setId(id);
		e.setSem(sem);
		e.setScode(scode);
		e.setSname(sname);
		e.setDate(date);
		e.setSess(sess);
		

		int status = TUserdatabase.tupdate(e);
		if (status > 0) {
			response.sendRedirect("viewtimetable");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
