package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/sviewworking")
public class sviewworking extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		List<WUser> list = WUserdatabase.getAllEmployees();
		out.println("<a href='studentdash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Working Hours List</h1>");
		
		out.print("<table border='1' width='50%'");
		out.print(
				"<tr><th>ID</th><th>YEAR</th><th>DATE </th><th>DAY</th><th>WORKING/HOLIDAY</th><th>TIMING</th></tr>");
		for (WUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getYear() + "</td><td>" + u.getDate() + "</td><td>"
					+ u.getDay() + "</td><td>" + u.getWork() + "</td><td>" + u.getTiming() 
					+ "</td></tr>");
		}
		out.print("</table>");

		out.close();
		out.print("</div>");
	}

	

}
