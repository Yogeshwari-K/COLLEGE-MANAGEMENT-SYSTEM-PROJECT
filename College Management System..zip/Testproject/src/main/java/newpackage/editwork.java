package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editwork")
public class editwork extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Details</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		WUser e = WUserdatabase.wgetEmployeeById(id);
		out.print("<form action='editwork1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
		out.print("<tr><td>Year:</td><td><input type='text' name='year' value='" + e.getYear() + "'/></td></tr>");
		out.print("<tr><td>Date:</td><td><input type='text' name='date' value='" + e.getDate()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Day:</td><td><input type='text' name='day' value='" + e.getDay() + "'/></td></tr>");
		out.print("<tr><td>Wroking/Holiday:</td><td><input type='text' name='work' value='" + e.getWork() + "'/></td></tr>");
		out.print("<tr><td>Timing:</td><td><input type='text' name='timing' value='" + e.getTiming() + "'/></td></tr>");
		
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
	}

	
}
