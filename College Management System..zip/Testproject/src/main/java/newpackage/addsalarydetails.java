package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addsalarydetails")
public class addsalarydetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		String  desig= request.getParameter("desig");
		double inc= Double.parseDouble(request.getParameter("inc"));
		
		double pd= Double.parseDouble(request.getParameter("pd"));
		
		String date=request.getParameter("date");
		SaUser u = SaUserdatabase.saget();
     double dir=u.getDir();
     double pri=u.getPri();
     double ad=u.getAd();
     double hod=u.getHod();
     double prof=u.getProf();
     double aprof=u.getAprof();
     double off=u.getOff();
     double sal=0;
     double ba=0;
     
     if(desig.equals("Director"))
		{
			sal=dir;
			 ba=(sal+inc-pd);
			
		}
     else if(desig.equals("Principal"))
     {
			sal=pri;
			 ba=(sal+inc-pd);
			
		}
     else if(desig.equals("Administrator"))
     {
    	 sal=ad;
		 ba=(sal+inc-pd);
     }
     else if(desig.equals("HOD"))
     {
    	 sal=hod;
		 ba=(sal+inc-pd);
     }
     else if(desig.equals("Professor"))
    		 {
    	 sal=prof;
		 ba=(sal+inc-pd);
    		 }
     else if(desig.equals("Ass.Professor"))
     {
    	 sal=aprof;
		 ba=(sal+inc-pd);
     }
     else if(desig.equals("Office Staff"))
     {
    	 sal=off;
		 ba=(sal+inc-pd);
     }
		SaaUser userModel = new SaaUser(name, dob, desig, inc, sal, pd, ba,date);
		// create a database model
		SaaUserdatabase regUser = new SaaUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
			response.sendRedirect("feeindex.html");
		} else {
			String errorMessage = "User Available";
			HttpSession regSession = request.getSession();
			regSession.setAttribute("RegError", errorMessage);
			response.sendRedirect("feeregisterationerror.jsp");
		}
	}

}
