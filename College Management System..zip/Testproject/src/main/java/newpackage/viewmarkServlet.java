package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewmarkServlet")
public class viewmarkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='addmark.jsp'>Add Marks</a>");
		out.println("<br>");
		List<MUser> list = MUserdatabase.getAllEmployees();
		out.println("<a href='staffdash.jsp'>back to Dashboard</a>");
		
		out.println("<div align='center'>");
		out.println("<h1>Test Marks </h1>");
		out.print("<table border='1' width='60%'");
		out.print(
				"<tr><th>ID</th><th>NAME</th><th>DEGREE</th><th>DEPARTMENT</th><th>SEMESTER</th><th>SUBJECT NAME</th><th>TOTAL MARKS</th><th>MARKS SCORED</th><th>EDIT</th><th>DELETE</th></tr>");
		for (MUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDegree() + "</td><td>"
					+ u.getDep() + "</td><td>" + u.getSem() + "</td><td>" + u.getSub() + "</td><td>" + u.getOutof() + "</td><td>" + u.getSmark() 
					+ "</td><td><a href='editmark?id=" + u.getId()
					+ "'>edit</a></td><td><a href='deletemark?id=" + u.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");

		out.close();
		out.println("</div>");
	}

	

}
