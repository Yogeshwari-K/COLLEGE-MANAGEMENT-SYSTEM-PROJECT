package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/faceditServlet")
public class faceditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Employee</h1>");
		String fid = request.getParameter("id");
		int id=Integer.parseInt(fid);
		FacUser face = FacUserdatabase.facgetEmployeeById(id);
		out.print("<form action='faceditServlet1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+face.getId()+"'/></td></tr>");  
		out.print("<tr><td>Name:</td><td><input type='text' name='name' value='" + face.getName() + "'/></td></tr>");
		out.print("<tr><td>Date of Birth:</td><td><input type='text' name='dob' value='" + face.getDob()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Gender:</td><td><input type='text' name='gender' value='" + face.getGender() + "'/></td></tr>");
		out.print("<tr><td>Qualification:</td><td><input type='text' name='quali' value='" + face.getQuali() + "'/></td></tr>");
		out.print("<tr><td>Specialization:</td><td><input type='text' name='spec' value='" + face.getSpec() + "'/></td></tr>");
		out.print("<tr><td>Email:</td><td><input type='text' name='email' value='" + face.getEmail() + "'/></td></tr>");

		out.print("<tr><td>Phone:</td><td><input type='text' name='phone' value='" + face.getPhone() + "'/></td></tr>");
		out.print("<tr><td>College:</td><td><input type='text' name='college' value='" + face.getCollege() + "'/></td></tr>");
		out.print("<tr><td>City:</td><td><input type='text' name='city' value='" + face.getCity() + "'/></td></tr>");
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
	}

	
}
