package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/salarydetails")
public class salarydetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='addsalarylist.jsp'>Add Details</a>");
		out.println("<br>");
		out.println("<a href='admindash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Salary List</h1>");
		List<SaaUser> list = SaaUserdatabase.getAllEmployees();
		out.print("<table border='1' width='80%'");
		out.print(
				"<tr><th>ID</th><th>NAME</th><th>DOB</th><th>DESIGNATION</th><th>INCREMENT</th><th>SALARY</th><th>PAID</th><th>BALANCE</th><th>DATE_OF_ISSUING</th><th>EDIT</th><th>DELETE</th></tr>");
		for (SaaUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDob() + "</td><td>"
					+ u.getDesig() + "</td><td>" + u.getInc() + "</td><td>" + u.getSal() + "</td><td>" + u.getPd()+ "</td><td>" + u.getBa()+ "</td><td>" + u.getDate()
					+ "</td><td><a href='editsaal?id=" + u.getId()
					+ "'>edit</a></td><td><a href='deleteSaal?id=" + u.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}

	
	

}
