package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewStudent")
public class viewStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='registration.jsp'>Add New Student</a>");
		out.println("<br>");
		out.println("<a href='admindash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Students List</h1>");
		List<User> list = UserDatabase.getAllEmployees();
		out.print("<table border='1' width='80%'");
		out.print(
				"<tr><th>ID</th><th>NAME</th><th>DOB</th><th>GENDER</th><th>DEGREE</th><th>DEP</th><th>SEM</th><th>EMAIL</th><th>PHONE</th><th>USERNAME</th><th>PASSWORD</th><th>EDIT</th><th>DELETE</th></tr>");
		for (User u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDob() + "</td><td>"
					+ u.getGender() + "</td><td>" + u.getDegree() + "</td><td>" + u.getDep() + "</td><td>" + u.getSem()
					+ "</td><td>" + u.getEmail() +"</td><td>" + u.getPhone() + "</td><td>" + u.getUsername() +"</td><td>" + u.getPassword() +"</td><td><a href='editStudent?id=" + u.getId()
					+ "'>edit</a></td><td><a href='deleteStudent?id=" + u.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}
	}

	

