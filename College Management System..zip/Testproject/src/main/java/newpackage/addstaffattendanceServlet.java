package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addstaffattendanceServlet")
public class addstaffattendanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String date=request.getParameter("date");
		String name = request.getParameter("name");
		
		String dep = request.getParameter("dep");
		
		String attend = request.getParameter("attend");
		
		
		
		StaffUser userModel = new StaffUser(date,name, dep, attend);
		// create a database model
		StaffUserdatabase regUser = new StaffUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
			response.sendRedirect("staffattendindex.html");
		} else {
			String errorMessage = "User Available";
			HttpSession regSession = request.getSession();
			regSession.setAttribute("RegError", errorMessage);
			response.sendRedirect("staffattendregisterationerror.jsp");
		}
	}

}
