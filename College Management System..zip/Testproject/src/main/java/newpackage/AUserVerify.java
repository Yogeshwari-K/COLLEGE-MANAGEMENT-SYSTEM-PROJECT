package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AUserVerify")
public class AUserVerify extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	try (PrintWriter out = response.getWriter()) {
		String email = request.getParameter("email");
        
  		//create instance object of the SendEmail Class
       ASendEmail sm = new ASendEmail();
  		//get the 6-digit code
       String code = sm.getRandom();
       
  		//craete new user using all information
       User1 user = new User1(email,code);
       
       //call the send email method
       boolean test = sm.sendEmail(user);
       
  		//check if the email send successfully
       if(test){
           HttpSession session1  = request.getSession();
           session1.setAttribute("authcode", user);
           response.sendRedirect("averify.jsp");
       }else{
  		  response.sendRedirect("afailed.jsp");
  	   }
		}
	}
}
