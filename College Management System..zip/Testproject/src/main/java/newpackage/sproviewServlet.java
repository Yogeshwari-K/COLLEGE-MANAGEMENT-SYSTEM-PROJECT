package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/sproviewServlet")
public class sproviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<a href='studentdash.jsp'>back to Dashboard</a>");
	
		HttpSession session=request.getSession();
		User  name= (User) session.getAttribute("loguser");
	    String name1=name.getName();
		User u = UserDatabase.get(name1);
		out.println("<div align='center'>");
		out.println("<h1>My Profile");
		out.print("<table border='1' width='80%'");
		out.print(
				"<tr><th>ID</th><th>NAME</th><th>DOB</th><th>GENDER</th><th>DEGREE</th><th>DEP</th><th>SEM</th><th>EMAIL</th><th>PHONE</th><th>USERNAME</th><th>PASSWORD</th><th>EDIT</th></tr>");
	
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDob() + "</td><td>"
					+ u.getGender() + "</td><td>" + u.getDegree() + "</td><td>" + u.getDep() + "</td><td>" + u.getSem()
					+ "</td><td>" + u.getEmail() +"</td><td>" + u.getPhone() + "</td><td>" + u.getUsername() +"</td><td>" + u.getPassword() +"</td><td><a href='editproStudent?id=" + u.getId()
					+ "'>edit</a></td></tr>");
		
		out.print("</table>");

		out.close();
	}

	

}
