package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TUserdatabase {
	Connection con ;
    public TUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(TUser tuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into timetable(Semester,Sub_code,Sub_name,Date,Session) values(?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, tuser.getSem());
           pt.setString(2,tuser.getScode());
           pt.setString(3,tuser.getSname());
           pt.setString(4,tuser.getDate()); 
           pt.setString(5,tuser.getSess());
           
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int tupdate(TUser e) {
		int status = 0;
		try {
			Connection con = TUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update timetable set Semester=?,Sub_code=?,Sub_name=?,Date=?,Session=? where Id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getSem());
			ps.setString(2,e.getScode());
			ps.setString(3, e.getSname());
			ps.setString(4, e.getDate());
			ps.setString(5, e.getSess());
			ps.setInt(6, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int tdelete(int id){  
        int status=0;  
        try{  
            Connection con=WUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from timetable where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  TUser tgetEmployeeById(int id) {
		TUser u = new TUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from timetable where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setSem(rs.getString(2));
				u.setScode(rs.getString(3));
				u.setSname(rs.getString(4));
				u.setDate(rs.getString(5));
				u.setSess(rs.getString(6));
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<TUser> getAllEmployees() {
		List<TUser> list = new ArrayList<TUser>();

		try {
			Connection con = WUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from timetable");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				TUser u = new TUser(); 
				u.setId(rs.getInt(1));
				u.setSem(rs.getString(2));
				u.setScode(rs.getString(3));
				u.setSname(rs.getString(4));
				u.setDate(rs.getString(5));
				u.setSess(rs.getString(6));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}}
