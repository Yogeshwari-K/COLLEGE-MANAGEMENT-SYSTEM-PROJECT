package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/peditServlet1")
public class peditServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String reg=request.getParameter("reg");
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		
		String degree=request.getParameter("degree");
		String dep=request.getParameter("dep");
		String year=request.getParameter("year");
		String cgpa= request.getParameter("cgpa");
		String com = request.getParameter("com");
		String sal=request.getParameter("sal");
		String des=request.getParameter("des");
		

		PUser e = new PUser();
		e.setId(id);
		e.setReg(reg);
		e.setName(name);
		e.setDob(dob);
		
		e.setDegree(degree);
		e.setDep(dep);
		e.setYear(year);
		e.setCgpa(cgpa);
		e.setCom(com);
		e.setSal(sal);
		e.setDes(des);
		
		
		int status = PUserdatabase.pupdate(e);
		if (status > 0) {
			response.sendRedirect("viewplacementServlet");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
