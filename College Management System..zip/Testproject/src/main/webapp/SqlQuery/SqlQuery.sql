create database data;
use data;
create table user1(id int not null auto_increment,name varchar(45) not null,email varchar(45) not null unique,password varchar(45) not null ,PRIMARY KEY (id));
select * from user1;
create table user2(id int not null auto_increment,name varchar(45) not null,email varchar(45) not null unique,password varchar(45) not null ,PRIMARY KEY (id));
select * from user2;
select * from user1;
create table register(name varchar(50) not null,password varchar(50) not null,email varchar(50),sex varchar(50),country varchar(50) not null);
create table login(email varchar(50),password varchar(50));
select * from login;
create table user3(id int not null auto_increment,name varchar(45) not null,password varchar(45) not null ,PRIMARY KEY (id));
select * from user3;
drop table user1;
create table user2(Id int not null auto_increment,Name varchar(45) not null ,Dob varchar(45) not null,Gender varchar(45) not null,Username varchar(45)not null,Email varchar(45) not null unique,Phone varchar(45)not null,password varchar(45) not null ,PRIMARY KEY (id));
select * from user2;
create table user1(Id int not null auto_increment,Name varchar(45) not null ,Dob varchar(45) not null,Gender varchar(45) not null,Degree varchar(45) ,Dep varchar(45)  ,Sem varchar(45) ,Email varchar(45) not null unique,Phone varchar(45)not null,Username varchar(45)not null,password varchar(45) not null ,PRIMARY KEY (id));
create table ugapply(Id int not null auto_increment,FName varchar(50) ,LName varchar(50),Dob varchar(50) ,Gender varchar(50) ,HscPercentage varchar(50) ,SslcPercentage varchar(50)  ,Degree varchar(50) ,Dep varchar(50) ,Email varchar(50) ,Phone varchar(50) ,HscGroup varchar(50) ,City varchar(50) ,PRIMARY KEY (id));
select * from  ugapply;

create table pgapply(Id int not null auto_increment,FName varchar(50) not null,LName varchar(50)not null,Dob varchar(50) not null,Gender varchar(50) not null,HscPercentage varchar(50) not null,SslcPercentage varchar(50) not null,Degree varchar(50) not null,Dep varchar(50) not null,Email varchar(50) not null,Phone varchar(50) not null,UgPercentage varchar(50) not null,City varchar(50) not null,PRIMARY KEY (id));
select * from user1;
drop table user1;
create table user1(Id int not null auto_increment,Name varchar(45)  ,Dob varchar(45) ,Gender varchar(45) ,Degree varchar(45) ,Dep varchar(45)  ,Sem varchar(45) ,Email varchar(45)  ,Phone varchar(45) ,Username varchar(45),password varchar(45) ,PRIMARY KEY (id));
create table faculty(Id int not null auto_increment,Name varchar(45)  ,Dob varchar(45) ,Gender varchar(45) ,Degree varchar(45) ,Specialization varchar(45)   ,Email varchar(45)  ,Phone varchar(45) ,College varchar(45),City varchar(45) ,PRIMARY KEY (id));
create table results(Id int not null auto_increment,Reg_No varchar(45),Name varchar(45) ,Dob varchar(45),Degree varchar(45),Department varchar(45),Semester varchar(45),Engg_Mathematics varchar(45),Engg_Physics varchar(45),Engg_Chemistry varchar(45),Engg_Graphics varchar(45),Communicative_English varchar(45),Environmental_Science varchar(45),Total_Marks varchar(45),Percentage varchar(45),Result varchar(45),PRIMARY KEY (id));

select * from results;
create table placement(Id int not null auto_increment,Reg_No varchar(45),Name varchar(45) ,Dob varchar(45),Degree varchar(45),Department varchar(45),Batch varchar(45),Cgpa varchar(45),Company varchar(60),Salary varchar(69),Designation varchar(50),PRIMARY KEY (id));
select * from placement;
create  table feestructure(Id int not null auto_increment,year varchar(45),Tution_Fees varchar(50),Placement_Fees varchar(50),Hostel_Fees varchar(50),Mess_Fees varchar(45),Other_Fees varchar(45),Total_Feesd double,Total_Feesh double ,primary key (id));
select * from feestructure;

create table feesdetails(Id int not null auto_increment,Name varchar(45),Degree varchar(45),Department varchar(45),Semester varchar(45),Hosteller varchar(45),Total_Fees double,Paid double,Balance double,primary key (id));
select * from feesdetails;
create table salary(Id int not null auto_increment,Name varchar(45),Dob varchar(45),Designation varchar(45),Increment double,Salary double,Issued double,Balance double,Date_Of_Issuing varchar(45),primary key (id));
select * from salary;

create table salStructure(Id int not null auto_increment,Year varchar(45),Director double,Principal double,Ao double,Hod double,Prof double,Aprof double,office double,primary key(id));
select * from salStructure;

create table whours(Id int not null auto_increment,Year varchar(45),Date varchar(45),Day varchar(45),Workornot varchar(45),Timing varchar(50),primary key(id));
select * from whours;
create table timetable(Id int not null auto_increment,Semester varchar(45),Sub_code varchar(45),Sub_name varchar(45),Date varchar(45),Session varchar(45),primary key(id));
select * from timetable;

create table schedule(Id  int not null auto_increment,Year varchar(45),Dep varchar(45),Sem varchar(45),Day varchar(45),first varchar(45),second varchar(45),third varchar(45),fourth varchar(45),Break varchar(45),fifth varchar(45),sixth varchar(45),seventh varchar(45),primary key(id));
create table marks(Id int not null auto_increment,Name varchar(45),Degree varchar(45),Dep varchar(45),Sem varchar(45),Sub varchar(45),outof varchar(45),scored varchar(45),primary key(id));
select * from marks;
create table attendance(Id int not null auto_increment,Date varchar(45),Name varchar(45),Degree varchar(45),Dep varchar(45),Sem varchar(45),Attendance varchar(45),Staff varchar(45),primary key(id));
select * from attendance;

create table staffschedule(Id  int not null auto_increment,Year varchar(45),Dep varchar(45),Sem varchar(45),Day varchar(45),first varchar(45),second varchar(45),third varchar(45),fourth varchar(45),Break varchar(45),fifth varchar(45),sixth varchar(45),seventh varchar(45),primary key(id));
create table stufeed(Id  int not null auto_increment,Name varchar(45),Degree varchar(45),Dep varchar(45),Training varchar(45),Feed varchar(200),primary key(id));
select * from staffschedule;
create table staffattendance(Id int not null auto_increment,Date varchar(45),Name varchar(45),Dep varchar(45),Attend varchar(45),primary key(id));
select * from staffattendance;

create table grade(Id int not null auto_increment,Reg_No varchar(45),Name varchar(45) ,Dob varchar(45),Degree varchar(45),Department varchar(45),Semester varchar(45),Engg_Mathematics varchar(45),Engg_Physics varchar(45),Engg_Chemistry varchar(45),Engg_Graphics varchar(45),Communicative_English varchar(45),Environmental_Science varchar(45),Total_Marks varchar(45),Percentage varchar(45),Result varchar(45),PRIMARY KEY (id));
select * from grade;
