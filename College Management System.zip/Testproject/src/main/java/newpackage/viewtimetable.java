package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/viewtimetable")
public class viewtimetable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='addtimetable.jsp'>Add Details</a>");
		out.println("<br>");
		out.println("<a href='admindash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Exam Time Table </h1>");
		List<TUser> list = TUserdatabase.getAllEmployees();
		out.print("<table border='1' width='50%'");
		out.print(
				"<tr><th>ID</th><th>SEMESTER</th><th>SUBJECT CODE </th><th>SUBJECT NAME</th><th>DATE</th><th>SESSION</th><th>EDIT</th><th>DELETE</th></tr>");
		for (TUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getSem() + "</td><td>" + u.getScode() + "</td><td>"
					+ u.getSname() + "</td><td>" + u.getDate() + "</td><td>" + u.getSess() 
					+ "</td><td><a href='edittable?id=" + u.getId()
					+ "'>edit</a></td><td><a href='deletetable?id=" + u.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}

	

}
