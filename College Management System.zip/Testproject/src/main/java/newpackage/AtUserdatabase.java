package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AtUserdatabase {
	Connection con ;
    public AtUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(AtUser atuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into attendance(Date,Name,Degree,Dep,Sem,attendance,staff) values(?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
          pt.setString(1, atuser.getDate());
           pt.setString(2, atuser.getName());
           pt.setString(3, atuser.getDegree());
           pt.setString(4, atuser.getDep());
           pt.setString(5, atuser.getSem());
           pt.setString(6,atuser.getAttend());
           pt.setString(7, atuser.getSi());
         
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int atupdate(AtUser e) {
		int status = 0;
		try {
			Connection con = FeUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update attendance set Date=?,Name=?,Degree=?,Dep=?,Sem=?,Attendance=?,Staff=? where Id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getDate());
			ps.setString(2, e.getName());
			ps.setString(3, e.getDegree());
			ps.setString(4,e.getDep() );
			ps.setString(5,e.getSem() );
			ps.setString(6, e.getAttend());
			ps.setString(7, e.getSi());
			
			ps.setInt(8, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int atdelete(int id){  
        int status=0;  
        try{  
            Connection con=SaUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from attendance where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  AtUser atgetEmployeeById(int id) {
		AtUser u = new AtUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from attendance where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setDate(rs.getString(2));
				u.setName(rs.getString(3));
				u.setDegree(rs.getString(4));
				u.setDep(rs.getString(5));
				u.setSem(rs.getString(6));
				u.setAttend(rs.getString(7));
				u.setSi(rs.getString(8));
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<AtUser> getAllEmployees() {
		List<AtUser> list = new ArrayList<AtUser>();

		try {
			Connection con = AtUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from attendance");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				AtUser u = new AtUser(); 
				u.setId(rs.getInt(1));
				u.setDate(rs.getString(2));
				u.setName(rs.getString(3));
				u.setDegree(rs.getString(4));
				u.setDep(rs.getString(5));
				u.setSem(rs.getString(6));
				u.setAttend(rs.getString(7));
				u.setSi(rs.getString(8));
				
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
	public static AtUser get(String username) {
		AtUser u = new AtUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from attendance where Name=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setDate(rs.getString(2));
				u.setName(rs.getString(3));
				u.setDegree(rs.getString(4));
				u.setDep(rs.getString(5));
				u.setSem(rs.getString(6));
				u.setAttend(rs.getString(7));
				u.setSi(rs.getString(8));
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return u;
	}
    
   
}
