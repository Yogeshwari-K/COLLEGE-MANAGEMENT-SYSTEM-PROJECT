package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addtimestructure")
public class addtimestructure extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String sem = request.getParameter("sem");
		String scode = request.getParameter("scode");
		String  sname= request.getParameter("sname");
		String date=request.getParameter("date");
		String sess = request.getParameter("sess");
		
	    
		//make user object
		TUser userModel = new TUser(sem,scode,sname,date,sess);
		

		//create a database model
		TUserdatabase regUser = new TUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
		   response.sendRedirect("tindex.html");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("tregisterationerror.html");
		    }
	}

}
