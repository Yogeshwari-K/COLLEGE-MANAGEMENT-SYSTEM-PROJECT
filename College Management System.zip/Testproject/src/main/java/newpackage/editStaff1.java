package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editStaff1")
public class editStaff1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String username=request.getParameter("username");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		
		String password=request.getParameter("password");

		FUser e = new FUser();
		e.setId(id);
		e.setName(name);
		e.setDob(dob);
		e.setGender(gender);
		e.setUsername(username);
		e.setEmail(email);
		e.setPhone(phone);
		
		e.setPassword(password);

		int status = FUserdatabase.fupdate(e);
		if (status > 0) {
			response.sendRedirect("view");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}
	}

