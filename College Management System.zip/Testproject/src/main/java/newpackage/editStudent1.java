package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/editStudent1")
public class editStudent1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String degree=request.getParameter("degree");
		String dep=request.getParameter("dep");
		String sem=request.getParameter("sem");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String username=request.getParameter("username");
		String password=request.getParameter("password");

		User e = new User();
		e.setId(id);
		e.setName(name);
		e.setDob(dob);
		e.setGender(gender);
		e.setDegree(degree);
		e.setDep(dep);
		e.setSem(sem);
		e.setEmail(email);
		e.setPhone(phone);
		e.setUsername(username);
		e.setPassword(password);

		int status = UserDatabase.update(e);
		if (status > 0) {
			response.sendRedirect("viewStudent");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}
	}


