package newpackage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class FacUserdatabase {
	Connection con ;
    public FacUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean facsaveUser(FacUser facuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into faculty(Name,Dob,Gender,Qualification,Specialization,Email,Phone,College,City) values(?,?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, facuser.getName());
           pt.setString(2,facuser.getDob());
           pt.setString(3,facuser.getGender());
           pt.setString(4, facuser.getQuali());
           pt.setString(5, facuser.getSpec());
           pt.setString(6,facuser.getEmail());
           pt.setString(7, facuser.getPhone());
           pt.setString(8, facuser.getCollege());
           pt.setString(9, facuser.getCity());     
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int facupdate(FacUser e) {
		int status = 0;
		try {
			Connection con = FacUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update faculty set Name=?,Dob=?,Gender=?,Qualification=?,Specialization=?,Email=?,Phone=?,College=?,City=? where Id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getName());
			ps.setString(2, e.getDob());
			ps.setString(3, e.getGender());
			ps.setString(4, e.getQuali());
			ps.setString(5, e.getSpec());
			ps.setString(6, e.getEmail());	
			ps.setString(7,e.getPhone());
			ps.setString(8, e.getCollege());
			ps.setString(9, e.getCity());
			ps.setInt(10, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int facdelete(int id){  
        int status=0;  
        try{  
            Connection con=FacUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from faculty where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  FacUser facgetEmployeeById(int id) {
		FacUser u = new FacUser();

		try {
			Connection con = FUserdatabase.getConnection();
			String query ="select * from faculty where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setGender(rs.getString(4));
				u.setQuali(rs.getString(5));
				u.setSpec(rs.getString(6));
				u.setEmail(rs.getString(7));
				u.setPhone(rs.getString(8));
				u.setCollege(rs.getString(9));
				u.setCity(rs.getString(10));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<FacUser> getAllEmployees() {
		List<FacUser> list = new ArrayList<FacUser>();

		try {
			Connection con = FacUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from faculty");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				FacUser u = new FacUser(); 
				 u.setId(rs.getInt(1));  
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setGender(rs.getString(4));
				u.setQuali(rs.getString(5));
				u.setSpec(rs.getString(6));
				u.setEmail(rs.getString(7));
				u.setPhone(rs.getString(8));
				u.setCollege(rs.getString(9));
				u.setCity(rs.getString(10));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
}
