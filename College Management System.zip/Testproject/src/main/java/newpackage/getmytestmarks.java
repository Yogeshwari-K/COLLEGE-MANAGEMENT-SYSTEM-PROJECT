package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/getmytestmarks")
public class getmytestmarks extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out = response.getWriter();
		HttpSession session=request.getSession();
		User  name= (User) session.getAttribute("loguser");
	    String name1=name.getName();
		MUser u = MUserdatabase.get(name1); 
		out.println("<a href='studentdash.jsp'>Back to Dashboard</a>");
		if(u!=null)
		{
		out.println("<div align='center'>");
		out.println("<h1>Your Test Marks </h1>");
		out.print("<table border='1' width='50%'");
		out.print(
		"<tr><th>ID</th><th>NAME</th><th>DEGREE</th><th>DEPARTMENT</th><th>SEMESTERR</th><th>SUBJECT</th><th>TOTAL MARKS</th><th>SCORED</th>></tr>");
		out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDegree() +"</td><td>"
				+ u.getDep() + "</td><td>" + u.getSem()+ "</td><td>" + u.getSub()+ "</td><td>" + u.getOutof() + "</td><td>" + u.getSmark()+ "</td></tr>");
		out.print("</table>");
		out.close();
		out.print("</div>");
		
	}else if(u==null)
	{
		out.println("No record Found.Will Update soon");
	}
		
	}
	}
	

	


