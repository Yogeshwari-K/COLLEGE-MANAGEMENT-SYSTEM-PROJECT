package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/getresultServlet")
public class getresultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String reg=request.getParameter("reg");
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		
		String degree=request.getParameter("degree");
		String dep=request.getParameter("dep");
		String sem=request.getParameter("sem");
		String em1 = request.getParameter("em");
		String ep1 = request.getParameter("ep");
		String ec1=request.getParameter("ec");
		String eg1=request.getParameter("eg");
		String ce1=request.getParameter("ce");
		String es1=request.getParameter("es");
		Float tm,per;
		String re;
		float em=Float.parseFloat(em1);
		float ep=Float.parseFloat(ep1);
		float ec=Float.parseFloat(ec1);
		float eg=Float.parseFloat(eg1);
		float ce=Float.parseFloat(ce1);
		float es=Float.parseFloat(es1);
		
		tm=(em+ep+ec+eg+ce+es);
		per=((tm/600)*100);
		re=null;
		if (per > 90) {
		    re = "A";
		} else if ((per > 80) && (per < 90)) {
		    re = "B";
		} else if ((per > 70) && (per < 80)) {
		    re = "C";
		} else if ((per > 60) && (per < 70)) {
		    re = "D";
		} else if ((per > 50) && (per < 60)) {
		    re = "E";
		} else if (per<50) {
		    re = "F";
		}
		String tm1=Float.toString(tm);
		String per1=Float.toString(per);
		ReUser userModel = new ReUser(reg,name,dob,degree,dep,sem, em1,ep1,ec1,eg1,ce1,es1,tm1,per1,re);
		

		//create a database model
		ReUserdatabase regUser = new ReUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
		   response.sendRedirect("reindex.jsp");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("reregisterationerror.jsp");
		    }
		
		
	}

}
