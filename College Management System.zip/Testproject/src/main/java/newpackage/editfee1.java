package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editfee1")
public class editfee1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String name = request.getParameter("name");
		String degree = request.getParameter("degree");
		String  dep= request.getParameter("dep");
		String sem=request.getParameter("sem");
		String hosteller = request.getParameter("hosteller");
		String  tf1 = request.getParameter("tf");
        String pd1=request.getParameter("pd");
       String  ba1=request.getParameter("ba");
       double tf=Double.parseDouble(tf1);
       double pd=Double.parseDouble(pd1);
       double ba=Double.parseDouble(ba1);
		FeeUser e = new FeeUser();
		e.setId(id);
		e.setName(name);
		e.setDegree(degree);
		e.setDep(dep);
		e.setSem(sem);
		e.setHosteller(hosteller);
		e.setTf(tf);
		e.setPd(pd);
		e.setBa(ba);

		int status = FeeUserdatabase.feeupdate(e);
		if (status > 0) {
			response.sendRedirect("feesdetails");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
