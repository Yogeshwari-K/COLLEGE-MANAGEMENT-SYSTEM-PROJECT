package newpackage;

public class FeedUser {
private int id;
private String name,degree,dep,training,feed;
public FeedUser()
{
	
}
public FeedUser(int id, String name, String degree, String dep, String training, String feed) {
	super();
	this.id = id;
	this.name = name;
	this.degree = degree;
	this.dep = dep;
	this.training = training;
	this.feed = feed;
}
public FeedUser(String name, String degree, String dep, String training, String feed) {
	super();
	this.name = name;
	this.degree = degree;
	this.dep = dep;
	this.training = training;
	this.feed = feed;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDegree() {
	return degree;
}
public void setDegree(String degree) {
	this.degree = degree;
}
public String getDep() {
	return dep;
}
public void setDep(String dep) {
	this.dep = dep;
}
public String getTraining() {
	return training;
}
public void setTraining(String training) {
	this.training = training;
}
public String getFeed() {
	return feed;
}
public void setFeed(String feed) {
	this.feed = feed;
}

}
