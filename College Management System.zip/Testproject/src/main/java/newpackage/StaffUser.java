package newpackage;

public class StaffUser {
private int id;
String date,name,dep,attend;
public StaffUser() {
	
}
public StaffUser(int id, String date, String name, String dep, String attend) {
	super();
	this.id = id;
	this.date = date;
	this.name = name;
	this.dep = dep;
	this.attend = attend;
}
public StaffUser(String date, String name, String dep, String attend) {
	super();
	this.date = date;
	this.name = name;
	this.dep = dep;
	this.attend = attend;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDep() {
	return dep;
}
public void setDep(String dep) {
	this.dep = dep;
}
public String getAttend() {
	return attend;
}
public void setAttend(String attend) {
	this.attend = attend;
}

}
