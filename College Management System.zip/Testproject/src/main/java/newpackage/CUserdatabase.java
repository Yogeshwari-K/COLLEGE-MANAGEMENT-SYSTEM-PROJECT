package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CUserdatabase {
	Connection con ;
    public CUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(CUser cuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into schedule(Year,Dep,Sem,Day,first,second,third,fourth,break,fifth,sixth,seventh) values(?,?,?,?,?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, cuser.getDegree());
           pt.setString(2, cuser.getDep());
           pt.setString(3,cuser.getSem());
           pt.setString(4,cuser.getDay());
           pt.setString(5,cuser.getFirst()); 
           pt.setString(6,cuser.getSecond());
           pt.setString(7, cuser.getThird());
           pt.setString(8,cuser.getFourth());
           pt.setString(9, cuser.getBre());
           pt.setString( 10, cuser.getFifth());
           
           pt.setString(11, cuser.getSixth());
           pt.setString(12, cuser.getSeventh());
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int cupdate(CUser e) {
		int status = 0;
		try {
			Connection con = CUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update schedule set Year=?,Dep=?,Sem=?,Day=?,first=?,second=?,third=?,fourth=?,break=?,fifth=?,sixth=?,seventh=? where Id=?");
			
			
			ps.setString(1, e.getDegree());
			ps.setString(2, e.getDep());
			ps.setString(3,e.getSem());
			ps.setString(4, e.getDay());
			ps.setString(5, e.getFirst());
			ps.setString(6, e.getSecond());
			ps.setString(7, e.getThird());
			ps.setString(8, e.getFourth());
			ps.setString(9, e.getBre());
			ps.setString(10, e.getFifth());
			ps.setString(11, e.getSixth());
			ps.setString(12, e.getSeventh());
			ps.setInt(13, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int cdelete(int id){  
        int status=0;  
        try{  
            Connection con=CUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from schedule where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  CUser cgetEmployeeById(int id) {
		CUser u = new CUser();

		try {
			Connection con = CUserdatabase.getConnection();
			String query ="select * from schedule where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setDegree(rs.getString(2));
				u.setDep(rs.getString(3));
				u.setSem(rs.getString(4));
				u.setDay(rs.getString(5));
				u.setFirst(rs.getString(6));
				u.setSecond(rs.getString(7));
				u.setThird(rs.getString(8));
				u.setFourth(rs.getString(9));
				u.setBre(rs.getString(10));
				u.setFifth(rs.getString(11));
				u.setSixth(rs.getString(12));
				u.setSeventh(rs.getString(13));
				
				
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<CUser> getAllEmployees() {
		List<CUser> list = new ArrayList<CUser>();

		try {
			Connection con = WUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from schedule");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				CUser u = new CUser(); 
				u.setId(rs.getInt(1));
				u.setDegree(rs.getString(2));
				u.setDep(rs.getString(3));
				u.setSem(rs.getString(4));
				u.setDay(rs.getString(5));
				u.setFirst(rs.getString(6));
				u.setSecond(rs.getString(7));
				u.setThird(rs.getString(8));
				u.setFourth(rs.getString(9));
				u.setBre(rs.getString(10));
				u.setFifth(rs.getString(11));
				u.setSixth(rs.getString(12));
				u.setSeventh(rs.getString(13));
				
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}}
