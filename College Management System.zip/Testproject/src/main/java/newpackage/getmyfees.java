package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/getmyfees")
public class getmyfees extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		User name = (User) session.getAttribute("loguser");
		String name1 = name.getName();

		FeeUser u = FeeUserdatabase.get(name1);
		out.println("<a href='studentdash.jsp'>Back to Dashboard</a>");
		if(u!=null)
		{
		
		out.println("<div align='center'>");
		out.println("<h1>Your Fees Details");
		out.print("<table border='1' width='50%'");
		out.print(
				"<tr><th>ID</th><th>NAME</th><th>DEGREE</th><th>DEPARTMENT</th><th>SEMESTER</th><th>HOSTELLER</th><th>TOTAL FEES</th><th>PAID</th><th>BALANCE</th></tr>");
		out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDegree() + "</td><td>"
				+ u.getDep() + "</td><td>" + u.getSem() + "</td><td>" + u.getHosteller() + "</td><td>" + u.getTf()
				+ "</td><td>" + u.getPd() + "</td><td>" + u.getBa() + "</td></tr>");
		out.print("</table>");
		out.close();
		out.print("</div>");
	}else if(u==null)
	{
		out.println("No record Found.Will Update soon");
	}
	}

}
