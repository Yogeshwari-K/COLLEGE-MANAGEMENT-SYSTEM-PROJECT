package newpackage;

public class CUser {
private int id;
private String degree,dep,sem,day,first,second,third,fourth,bre,fifth,sixth,seventh;
public CUser()
{
	
}
public CUser(String degree,String dep, String sem, String day, String first, String second, String third, String fourth, String bre,
		String fifth, String sixth, String seventh) {
	super();
	this.degree=degree;
	this.dep = dep;
	this.sem = sem;
	this.day = day;
	this.first = first;
	this.second = second;
	this.third = third;
	this.fourth = fourth;
	this.bre = bre;
	this.fifth = fifth;
	this.sixth = sixth;
	this.seventh = seventh;
}
public CUser(int id, String degree,String dep, String sem, String day, String first, String second, String third, String fourth,
		String bre, String fifth, String sixth, String seventh) {
	super();
	this.id = id;
	this.degree=degree;
	this.dep = dep;
	this.sem = sem;
	this.day = day;
	this.first = first;
	this.second = second;
	this.third = third;
	this.fourth = fourth;
	this.bre = bre;
	this.fifth = fifth;
	this.sixth = sixth;
	this.seventh = seventh;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getDegree() {
	return degree;
}
public void setDegree(String degree) {
	this.degree= degree;
}
public String getDep() {
	return dep;
}
public void setDep(String dep) {
	this.dep = dep;
}
public String getSem() {
	return sem;
}
public void setSem(String sem) {
	this.sem = sem;
}
public String getDay() {
	return day;
}
public void setDay(String day) {
	this.day = day;
}
public String getFirst() {
	return first;
}
public void setFirst(String first) {
	this.first = first;
}
public String getSecond() {
	return second;
}
public void setSecond(String second) {
	this.second = second;
}
public String getThird() {
	return third;
}
public void setThird(String third) {
	this.third = third;
}
public String getFourth() {
	return fourth;
}
public void setFourth(String fourth) {
	this.fourth = fourth;
}
public String getBre() {
	return bre;
}
public void setBre(String bre) {
	this.bre = bre;
}
public String getFifth() {
	return fifth;
}
public void setFifth(String fifth) {
	this.fifth = fifth;
}
public String getSixth() {
	return sixth;
}
public void setSixth(String sixth) {
	this.sixth = sixth;
}
public String getSeventh() {
	return seventh;
}
public void setSeventh(String seventh) {
	this.seventh = seventh;
}


}
