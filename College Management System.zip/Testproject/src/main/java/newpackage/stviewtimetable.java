package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/stviewtimetable")
public class stviewtimetable extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='addclasstimetable.jsp'>Add Details</a>");
		out.println("<br>");
		out.println("<a href='admindash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1> Class Time Table</h1>");
		List<CUser> list = CUserdatabase.getAllEmployees();
		out.print("<table border='1' width='60%'");
		out.print(
				"<tr><th>ID</th><th>DEGREE</th><th>DEPARTMENT</th><th>SEMESTER</th><th>DAY/PERIODS</th><th>I</th><th>II</th><th>III</th><th>IV</th><th>V</th><th>VI</th><th>VII</th></tr>");
		for (CUser u : list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getDegree()+ "</td><td>" + u.getDep() + "</td><td>" + u.getSem() + "</td><td>"
					+ u.getDay() + "</td><td>" + u.getFirst() + "</td><td>" + u.getSecond() + "</td><td>" + u.getThird()
					+ "</td><td>" + u.getFourth() + "</td><td>" + u.getBre() + "</td><td>" + u.getSixth() + "</td><td>"
					+ u.getSeventh() + "</td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}

}
