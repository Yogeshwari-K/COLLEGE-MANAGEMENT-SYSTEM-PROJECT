package newpackage;
	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
	import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

	public class PgUserdatabase {
			Connection con ;
	public PgUserdatabase(Connection con) {
	        this.con = con;
	    } 
	 public static Connection getConnection() {
			Connection con = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
			} catch (Exception e) {
				System.out.println(e);
			}
			return con;
		}
	    //for register user 
	    public boolean saveUser(PgUser pguser){
	        boolean set = false;
	        try{
	            //Insert register data to database
	        	String query = "insert into pgapply(FName,LName,Dob,Gender,HscPercentage,SslcPercentage,Degree,Dep,Email,Phone,UgPercentage,City) values(?,?,?,?,?,?,?,?,?,?,?,?)";
	        	 PreparedStatement pgpt = this.con.prepareStatement(query);
	             pgpt.setString(1, pguser.getFname());
	             pgpt.setString(2,pguser.getLname());
	             pgpt.setString(3,pguser.getDob());
	             pgpt.setString(4,pguser.getGender());
	             pgpt.setString(5, pguser.getHscp());
	             pgpt.setString(6, pguser.getHscp());
	             pgpt.setString(7, pguser.getDegree());
	             pgpt.setString(8, pguser.getDep());
	             pgpt.setString(9, pguser.getEmail());
	             pgpt.setString(10,pguser.getPhone());
	             pgpt.setString(11, pguser.getUgp());
	             pgpt.setString(12, pguser.getCity());
	             
	             pgpt.executeUpdate();
	             set = true;
	          }catch(Exception e){
	              e.printStackTrace();
	          }
	          return set;
	    }   
	    public static int delete(int id){  
	        int status=0;  
	        try{  
	            Connection con=PgUserdatabase.getConnection();  
	            PreparedStatement ps=con.prepareStatement("delete from pgapply where Id=?");  
	            ps.setInt(1,id);  
	            status=ps.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception e)
	        {e.printStackTrace();
	        }  
	          
	        return status;  
	    } 
	        
	    public static int update(PgUser e) {
			int status = 0;
			try {
				Connection con =PgUserdatabase.getConnection();
				PreparedStatement ps = con.prepareStatement(
						"update pgapply set FName=?,LName=?,Dob=?,Gender=?,HscPercentage=?,SslcPercentage=?,Degree=?,Dep=?,Email=?,Phone=?,UgPercentage=?,City=? where Id=?");
				//ps.setInt(1, e.getId());
				ps.setString(1, e.getFname());
				ps.setString(2, e.getLname());
				ps.setString(3, e.getDob());
				ps.setString(4, e.getGender());
				ps.setString(5, e.getHscp());
				ps.setString(6, e.getSslcp());	
				ps.setString(7,e.getDegree());
				ps.setString(8, e.getDep());
				ps.setString(9, e.getEmail());
				ps.setString(10, e.getPhone());	
				ps.setString(11, e.getUgp());
				ps.setString(12, e.getCity());
				ps.setInt(13, e.getId());
				status = ps.executeUpdate();
				con.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return status;
		}
	    public static  PgUser getEmployeeById(int id) {
			PgUser u = new PgUser();

			try {
				Connection con = PgUserdatabase.getConnection();
				String query ="select * from pgapply where Id=?";
	            PreparedStatement pst = con.prepareStatement(query);
				pst.setInt(1, id);
				ResultSet rs = pst.executeQuery();
				if (rs.next()) { 
					u.setId(rs.getInt(1));
					u.setFname(rs.getString(2));
					u.setLname(rs.getString(3));
					u.setDob(rs.getString(4));
					u.setGender(rs.getString(5));
					u.setHscp(rs.getString(6));
					u.setSslcp(rs.getString(7));
					u.setDegree(rs.getString(8));
					u.setDep(rs.getString(9));
					u.setEmail(rs.getString(10));
					u.setPhone(rs.getString(11));
					u.setUgp(rs.getString(12));
					u.setCity(rs.getString(13));
					
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return u;
		}

		public static  List<PgUser> getAllEmployees() {
			List<PgUser> list = new ArrayList<PgUser>();

			try {
				Connection con = UgUserdatabase.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from pgapply");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					PgUser u = new PgUser(); 
					u.setId(rs.getInt(1));
					u.setFname(rs.getString(2));
					u.setLname(rs.getString(3));
					u.setDob(rs.getString(4));
					u.setGender(rs.getString(5));
					u.setHscp(rs.getString(6));
					u.setSslcp(rs.getString(7));
					u.setDegree(rs.getString(8));
					u.setDep(rs.getString(9));
					u.setEmail(rs.getString(10));
					u.setPhone(rs.getString(11));
					u.setUgp(rs.getString(12));
					u.setCity(rs.getString(13));
					list.add(u);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}

			return list;
	

	}
}