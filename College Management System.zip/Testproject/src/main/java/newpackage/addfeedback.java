package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addfeedback")
public class addfeedback extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name= request.getParameter("name");
		String degree=request.getParameter("degree");
		String dep=request.getParameter("dep");
		String training=request.getParameter("training");
		String feed=request.getParameter("feed");
		FeedUser userModel = new FeedUser(name,degree,dep,training,feed);
		

		//create a database model
		FeedUserdatabase regUser = new FeedUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
		   response.sendRedirect("feedindex.html");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("feedregistrationerror.jsp");
	}

}}
