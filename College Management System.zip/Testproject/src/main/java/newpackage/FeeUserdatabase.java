package newpackage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class FeeUserdatabase {
	Connection con ;
    public FeeUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(FeeUser feeuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into feesdetails(Name,Degree,Department,Semester,Hosteller,Total_Fees,Paid,Balance) values(?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, feeuser.getName());
           pt.setString(2,feeuser.getDegree());
           pt.setString(3,feeuser.getDep());
           pt.setString(4, feeuser.getSem());
           pt.setString(5, feeuser.getHosteller());
           pt.setDouble(6,feeuser.getTf());
           pt.setDouble(7, feeuser.getPd());
           pt.setDouble(8, feeuser.getBa());
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int feeupdate(FeeUser e) {
		int status = 0;
		try {
			Connection con = FeUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update feesdetails set Name=?,Degree=?,Department=?,Semester=?,Hosteller=?,Total_Fees=?,Paid=?,Balance=? where id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getName());
			ps.setString(2, e.getDegree());
			ps.setString(3, e.getDep());
			ps.setString(4, e.getSem());
			ps.setString(5, e.getHosteller());
			ps.setDouble(6, e.getTf());
			ps.setDouble(7, e.getPd());	
			ps.setDouble(8, e.getBa());
			ps.setInt(9, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int feedelete(int id){  
        int status=0;  
        try{  
            Connection con=FeeUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from feesdetails where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  FeeUser feegetEmployeeById(int id) {
		FeeUser u = new FeeUser();

		try {
			Connection con = FeeUserdatabase.getConnection();
			String query ="select * from feesdetails where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setSem(rs.getString(5));
				u.setHosteller(rs.getString(6));
				u.setTf(rs.getDouble(7));
				u.setPd(rs.getDouble(8));
				u.setBa(rs.getDouble(9));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<FeeUser> getAllEmployees() {
		List<FeeUser> list = new ArrayList<FeeUser>();

		try {
			Connection con = FacUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from feesdetails");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				FeeUser u = new FeeUser(); 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setSem(rs.getString(5));
				u.setHosteller(rs.getString(6));
				u.setTf(rs.getDouble(7));
				u.setPd(rs.getDouble(8));
				u.setBa(rs.getDouble(9));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
    public static FeeUser get(String username) {
		FeeUser u = new FeeUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from feesdetails where Name=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setSem(rs.getString(5));
				u.setHosteller(rs.getString(6));
				u.setTf(rs.getDouble(7));
				u.setPd(rs.getDouble(8));
				u.setBa(rs.getDouble(9));
				
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return u;
	}
    
    }
