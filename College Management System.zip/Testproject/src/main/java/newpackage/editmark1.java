package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editmark1")
public class editmark1 extends HttpServlet {
	private static final long serialVersionUID = 1L;


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String name = request.getParameter("name");
		String degree = request.getParameter("degree");
		String  dep= request.getParameter("dep");
		String sem=request.getParameter("sem");
		String sub = request.getParameter("sub");
		String  outof = request.getParameter("outof");
        String smark=request.getParameter("smark");
      
		MUser e = new MUser();
		e.setId(id);
		e.setName(name);
		e.setDegree(degree);
		e.setDep(dep);
		e.setSem(sem);
		e.setSub(sub);
		e.setOutof(outof);
		e.setSmark(smark);
		

		int status = MUserdatabase.mupdate(e);
		if (status > 0) {
			response.sendRedirect("viewmarkServlet");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
