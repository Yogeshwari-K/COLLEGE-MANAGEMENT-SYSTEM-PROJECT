package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/editsal")
public class editsal extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Salary</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		SaUser e = SaUserdatabase.sagetEmployeeById(id);
		out.print("<form action='editsal1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
		out.print("<tr><td>Year:</td><td><input type='text' name='year' value='" + e.getYear() + "'/></td></tr>");
		out.print("<tr><td>Director:</td><td><input type='text' name='dir' value='" + e.getDir()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Principal:</td><td><input type='text' name='pri' value='" + e.getPri() + "'/></td></tr>");
		out.print("<tr><td>Administrator:</td><td><input type='text' name='ad' value='" + e.getAd() + "'/></td></tr>");
		out.print("<tr><td>HOD:</td><td><input type='text' name='hod' value='" + e.getHod() + "'/></td></tr>");
		out.print("<tr><td>Professor:</td><td><input type='text' name='prof' value='" + e.getProf() + "'/></td></tr>");
		out.print("<tr><td>Assistant Professor:</td><td><input type='text' name='aprof' value='" + e.getAprof() + "'/></td></tr>");
		out.print("<tr><td>Office Staff:</td><td><input type='text' name='off' value='" + e.getOff() + "'/></td></tr>");
		
		
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");


		out.close();
	}

	

}
