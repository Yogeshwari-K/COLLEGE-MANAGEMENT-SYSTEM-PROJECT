package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/editproServlet")
public class editproServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try (PrintWriter out = response.getWriter()) {
			String alogname = request.getParameter("name");
			String alogpass = request.getParameter("password");

			AUserdatabase adb = new AUserdatabase(ConnectionPro.getConnection());
			AUser u = AUserdatabase.getAllEmployees(alogname, alogpass);

			out.println("<a href='addsalarylist.jsp'>Add Details</a>");
			out.println("<br>");
			out.println("<a href='admindash.jsp'>back to Dashboard</a>");
			out.println("<h1>Salary List</h1>");
			// List<SaaUser> list = SaaUserdatabase.getAllEmployees();
			out.print("<table border='1' width='50%'");
			out.print("<tr><th>ID</th><th>USERNAME</th><th>PASSWORD</th><th>EDIT</th></tr>");
			// for (AUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getPassword() 
					+ "</td><td><a href='editsaal?id=" + u.getId() + "'>edit</a></td> </tr>");
			// }
			out.print("</table>");

			out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
