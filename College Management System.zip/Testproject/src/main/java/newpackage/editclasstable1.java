package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editclasstable1")
public class editclasstable1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String degree=request.getParameter("degree");
		String dep = request.getParameter("dep");
		String sem = request.getParameter("sem");
		String  day= request.getParameter("day");
		String first=request.getParameter("first");
		String second = request.getParameter("second");
		String third= request.getParameter("third");
		String  fourth= request.getParameter("fourth");
		String bre=request.getParameter("bre");
		String fifth=request.getParameter("fifth");
		String sixth = request.getParameter("sixth");
		String seventh = request.getParameter("seventh");
		
		
		
		CUser e = new CUser();
		e.setId(id);
		e.setDegree(degree);
		e.setDep(dep);
		e.setSem(sem);
		e.setDay(day);
		e.setFirst(first);
		e.setSecond(second);
		e.setThird(third);
		e.setFourth(fourth);
		e.setBre(bre);
		e.setFifth(fifth);
		e.setSixth(sixth);
		e.setSeventh(seventh);
		
		

		int status = CUserdatabase.cupdate(e);
		if (status > 0) {
			response.sendRedirect("viewclasstimetable");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
}}
