package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FeUserdatabase {
	Connection con ;
    public FeUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(FeUser feuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into feestructure(year,Tution_Fees,Placement_Fees,Hostel_Fees,Mess_Fees,Other_Fees,Total_Feesd,Total_Feesh) values(?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, feuser.getYear());
           pt.setString(2,feuser.getTution());
           pt.setString(3,feuser.getPlace());
           pt.setString(4, feuser.getHostel());
           pt.setString(5, feuser.getMess());
           pt.setString(6,feuser.getOther());
           pt.setDouble(7, feuser.getTotal());
           pt.setDouble(8,feuser.getTotalh());
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int feupdate(FeUser e) {
		int status = 0;
		try {
			Connection con = FeUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update feestructure set year=?,Tution_Fees=?,Placement_Fees=?,Hostel_Fees=?,Mess_Fees=?,Other_Fees=?,Total_Feesd=?,Total_Feesh=? where Id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getYear());
			ps.setString(2, e.getTution());
			ps.setString(3, e.getPlace());
			ps.setString(4, e.getHostel());
			ps.setString(5, e.getMess());
			ps.setString(6, e.getOther());	
			ps.setDouble(7, e.getTotal());
			ps.setDouble(8,e.getTotalh());
			ps.setInt(9, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int fedelete(int id){  
        int status=0;  
        try{  
            Connection con=FeUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from feestructure where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  FeUser fegetEmployeeById(int id) {
		FeUser u = new FeUser();

		try {
			Connection con = FeUserdatabase.getConnection();
			String query ="select * from feestructure where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setYear(rs.getString(2));
				u.setTution(rs.getString(3));
				u.setPlace(rs.getString(4));
				u.setHostel(rs.getString(5));
				u.setMess(rs.getString(6));
				u.setOther(rs.getString(7));
				u.setTotal(rs.getDouble(8));
				u.setTotalh(rs.getDouble(9));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<FeUser> getAllEmployees() {
		List<FeUser> list = new ArrayList<FeUser>();

		try {
			Connection con = FeUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from feestructure");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				FeUser u = new FeUser(); 
				 u.setId(rs.getInt(1));  
				u.setYear(rs.getString(2));
				u.setTution(rs.getString(3));
				u.setPlace(rs.getString(4));
				u.setHostel(rs.getString(5));
				u.setMess(rs.getString(6));
				u.setOther(rs.getString(7));
				u.setTotal(rs.getDouble(8));
				u.setTotalh(rs.getDouble(9));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
    
    public static  FeUser feget() {
		FeUser u = new FeUser();

		try {
			Connection con = FeUserdatabase.getConnection();
			String query ="select * from feestructure ";
            PreparedStatement pst = con.prepareStatement(query);
			
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setYear(rs.getString(2));
				u.setTution(rs.getString(3));
				u.setPlace(rs.getString(4));
				u.setHostel(rs.getString(5));
				u.setMess(rs.getString(6));
				u.setOther(rs.getString(7));
				u.setTotal(rs.getDouble(8));
				u.setTotalh(rs.getDouble(9));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
}
