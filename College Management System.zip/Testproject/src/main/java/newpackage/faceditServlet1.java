package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/faceditServlet1")
public class faceditServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String quali=request.getParameter("quali");
		String spec= request.getParameter("spec");
		String email = request.getParameter("email");
		String phone= request.getParameter("phone");
		String college = request.getParameter("college");
		String city=request.getParameter("city");
		
		
		

		FacUser e = new FacUser();
		e.setId(id);
		e.setName(name);
		e.setDob(dob);
		e.setGender(gender);
		e.setQuali(quali);
		e.setSpec(spec);
		e.setEmail(email);
		e.setPhone(phone);
		e.setCollege(college);
		e.setCity(city);

		int status = FacUserdatabase.facupdate(e);
		if (status > 0) {
			response.sendRedirect("viewFaculty");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
