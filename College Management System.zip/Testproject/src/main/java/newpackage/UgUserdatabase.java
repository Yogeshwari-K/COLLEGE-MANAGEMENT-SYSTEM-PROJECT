package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UgUserdatabase {
		Connection con ;

	    public UgUserdatabase(Connection con) {
	        this.con = con;
	    }
	    public static Connection getConnection() {
			Connection con = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
			} catch (Exception e) {
				System.out.println(e);
			}
			return con;
		}
	    //for register user 
	    public boolean saveUser(UgUser uguser){
	        boolean set = false;
	        try{
	            //Insert register data to database
	        	String query = "insert into ugapply(FName,LName,Dob,Gender,HscPercentage,SslcPercentage,Degree,Dep,Email,Phone,HscGroup,City) values(?,?,?,?,?,?,?,?,?,?,?,?)";
	        	 PreparedStatement ugpt = this.con.prepareStatement(query);
	             ugpt.setString(1, uguser.getFname());
	             ugpt.setString(2,uguser.getLname());
	             ugpt.setString(3,uguser.getDob());
	             ugpt.setString(4,uguser.getGender());
	             ugpt.setString(5, uguser.getHscp());
	             ugpt.setString(6, uguser.getSslcp());
	             ugpt.setString(7, uguser.getDegree());
	             ugpt.setString(8, uguser.getDep());
	             ugpt.setString(9, uguser.getEmail());
	             ugpt.setString(10,uguser.getPhone());
	             ugpt.setString(11, uguser.getHscg());
	             ugpt.setString(12, uguser.getCity());
	             
	             
	             ugpt.executeUpdate();
	             set = true;
	          }catch(Exception e){
	              e.printStackTrace();
	          }
	          return set;
	      }
	      //user login
	    
	    public static int delete(int id){  
	        int status=0;  
	        try{  
	            Connection con=UgUserdatabase.getConnection();  
	            PreparedStatement ps=con.prepareStatement("delete from ugapply where Id=?");  
	            ps.setInt(1,id);  
	            status=ps.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception e)
	        {e.printStackTrace();
	        }  
	          
	        return status;  
	    } 
	        
	    public static int update(UgUser e) {
			int status = 0;
			try {
				Connection con =UgUserdatabase.getConnection();
				PreparedStatement ps = con.prepareStatement(
						"update ugapply set FName=?,LName=?,Dob=?,Gender=?,HscPercentage=?,SslcPercentage=?,Degree=?,Dep=?,Email=?,Phone=?,HscGroup=?,City=? where Id=?");
				//ps.setInt(1, e.getId());
				ps.setString(1, e.getFname());
				ps.setString(2, e.getLname());
				ps.setString(3, e.getDob());
				ps.setString(4, e.getGender());
				ps.setString(5, e.getHscp());
				ps.setString(6, e.getSslcp());	
				ps.setString(7,e.getDegree());
				ps.setString(8, e.getDep());
				ps.setString(9, e.getEmail());
				ps.setString(10, e.getPhone());	
				ps.setString(11, e.getHscg());
				ps.setString(12, e.getCity());
				ps.setInt(13, e.getId());
				status = ps.executeUpdate();
				con.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return status;
		}
	    public static  UgUser getEmployeeById(int id) {
			UgUser u = new UgUser();

			try {
				Connection con = UgUserdatabase.getConnection();
				String query ="select * from ugapply where Id=?";
	            PreparedStatement pst = con.prepareStatement(query);
				pst.setInt(1, id);
				ResultSet rs = pst.executeQuery();
				if (rs.next()) { 
					u.setId(rs.getInt(1));
					u.setFname(rs.getString(2));
					u.setLname(rs.getString(3));
					u.setDob(rs.getString(4));
					u.setGender(rs.getString(5));
					u.setHscp(rs.getString(6));
					u.setSslcp(rs.getString(7));
					u.setDegree(rs.getString(8));
					u.setDep(rs.getString(9));
					u.setEmail(rs.getString(10));
					u.setPhone(rs.getString(11));
					u.setHscg(rs.getString(12));
					u.setCity(rs.getString(13));
					
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return u;
		}

		public static  List<UgUser> getAllEmployees() {
			List<UgUser> list = new ArrayList<UgUser>();

			try {
				Connection con = UgUserdatabase.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from ugapply");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					UgUser u = new UgUser(); 
					u.setId(rs.getInt(1));
					u.setFname(rs.getString(2));
					u.setLname(rs.getString(3));
					u.setDob(rs.getString(4));
					u.setGender(rs.getString(5));
					u.setHscp(rs.getString(6));
					u.setSslcp(rs.getString(7));
					u.setDegree(rs.getString(8));
					u.setDep(rs.getString(9));
					u.setEmail(rs.getString(10));
					u.setPhone(rs.getString(11));
					u.setHscg(rs.getString(12));
					u.setCity(rs.getString(13));
					list.add(u);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}

			return list;
	
}}
