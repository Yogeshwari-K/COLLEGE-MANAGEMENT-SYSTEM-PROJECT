package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewstufeedback")
public class viewstufeedback extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='admindash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Feedback Details </h1>");
		List<FeedUser> list = FeedUserdatabase.getAllEmployees();
		out.print("<table border='1' width='70%'");
		out.print(
				"<tr><th>ID</th><th>SEMESTER</th><th>SUBJECT CODE </th><th>SUBJECT NAME</th><th>DATE</th><th>SESSION</th><th>DELETE</th></tr>");
		for (FeedUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDegree() + "</td><td>"
					+ u.getDep() + "</td><td>" + u.getTraining() + "</td><td>" + u.getFeed() +"</td><td><a href='deletefeed?id=" + u.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.close();
		out.println("</div>");
	}


}
