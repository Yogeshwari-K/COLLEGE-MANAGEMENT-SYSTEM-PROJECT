package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/salaryStructure")
public class salaryStructure extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='addsalary.jsp'>Add Details</a>");
		out.println("<br>");
		out.println("<a href='admindash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Salary Structure</h1>");
		List<SaUser> list = SaUserdatabase.getAllEmployees();
		out.print("<table border='1' width='80%'");
		out.print(
				"<tr><th>ID</th><th>YEAR</th><th>DIRECTOR</th><th>PRINCIPAL</th><th>ADMINISTRATOR</th><th>HOD</th><th>PROFESSOR</th><th>ASS.PROFESSOR</th><th>OFFICE STAFFS</th><th>EDIT</th><th>DELETE</th></tr>");
		for (SaUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getYear() + "</td><td>" + u.getDir() + "</td><td>"
					+ u.getPri() + "</td><td>" + u.getAd() + "</td><td>" + u.getHod() + "</td><td>" + u.getProf()+ "</td><td>" + u.getAprof()+ "</td><td>" + u.getOff()
					+"</td><td><a href='editsal?id=" + u.getId()+ "'>edit</a></td><td><a href='deletesal?id=" + u.getId()+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}

	
}
