package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/getgrade")
public class getgrade extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String reg=request.getParameter("reg");
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		
		String degree=request.getParameter("degree");
		String dep=request.getParameter("dep");
		String sem=request.getParameter("sem");
		String em1 = request.getParameter("em");
		String ep1 = request.getParameter("ep");
		String ec1=request.getParameter("ec");
		String eg1=request.getParameter("eg");
		String ce1=request.getParameter("ce");
		String es1=request.getParameter("es");
		Float tm,per;
	
		float em=Float.parseFloat(em1);
		float ep=Float.parseFloat(ep1);
		float ec=Float.parseFloat(ec1);
		float eg=Float.parseFloat(eg1);
		float ce=Float.parseFloat(ce1);
		float es=Float.parseFloat(es1);
		
		tm=(em+ep+ec+eg+ce+es);
		per=((tm/600)*100);
   String re ="A";
		if (per > 90) {
		    re = "A";
		} else if ((per > 80) && (per < 90)) {
		    re = "B";
		} else if ((per > 70) && (per < 80)) {
		    re = "C";
		} else if ((per > 60) && (per < 70)) {
		    re = "D";
		} else if ((per > 50) && (per < 60)) {
		    re = "E";
		} else if (per<50) {
		    re = "F";
		}
		String tm1=Float.toString(tm);
		String per1=Float.toString(per);
		GrUser userModel = new GrUser(reg,name,dob,degree,dep,sem, em1,ep1,ec1,eg1,ce1,es1,tm1,per1,re);
		

		//create a database model
		GrUserdatabase regUser = new GrUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
			PrintWriter out = response.getWriter();
			String reg1=request.getParameter("reg");
			out.println("<a href='calculator.html'>Grade Calculator</a>");
			out.println("<br>");
			out.println("<a href='studentdash.jsp'>Back to Dashboard</a>");
			out.println("<div align='center'>");
			out.println("<h1>Your Result</h1>");
			GrUser u = GrUserdatabase.getEmployeeByIdd(reg1);
			out.print("<table border='1' width='30%'");
		/*	out.print(
					"<tr><th>ID</th><th>REGISTER NUMBER</th><th>NAME</th><th>DOB</th><th>DEGREE</th><th>DEPARTMENT</th><th>SEMESTER</th><th>ENGINEERING MATHS</th><th>ENGINEERING PHYSICS</th><th>ENGINEERING CHEMISTRY</th><th>ENGINEERING GRAPHICS</th><th>COMMUNICATION ENGLISH</th><th>ENVIRONMENTAL SCIENCE</th><th>TOTAL MARKS</th><th>PERCENTAGE</th><th>RESULT</th></tr>");
			
				out.print("</td><td>" + u.getId() + "</td><td>" + u.getReg() + "</td><td>" + u.getName() + "</td><td>"
						+ u.getDob() + "</td><td>" + u.getDegree() + "</td><td>" + u.getDep() + "</td><td>" + u.getSem()
						+ "</td><td>" + u.getEm() + "</td><td>" + u.getEp() + "</td><td>" + u.getEc() + "</td><td>"
						+ u.getEg() + "</td><td>" + u.getCe() + "</td><td>" + u.getEs() + "</td><td>" + u.getTm()
						+ "</td><td>" + u.getPer() + "</td><td>" + u.getRe() + "</td></tr>");
			*/
			out.print("<tr><td>ID</td><td>" + u.getId() + "</td></tr><tr><td>REGISTER NUMBER</td><td> "
					+ u.getReg() + "</td></tr><tr><td>NAME</td><td>" + u.getName()
					+ "</td></tr><tr><td>DOB</td><td>" + u.getDob() + "</td></tr><tr><td>DEGREE</td><td>"
					+ u.getDegree() + "</td></tr><tr><td>DEPARTMENT</td><td>" + u.getDep()
					+ "</td></tr><tr><td>SEMESTER</td><td>" + u.getSem()
					+ "</td></tr><tr><td>ENGINEERING MATHS</td><td>" + u.getEm()
					+ "</td></tr><tr><td>ENGINEERING PHYSICS</td><td>" + u.getEp()
					+ "</td></tr><tr><td>ENGINEERING CHEMISTRY</td><td>" + u.getEc()
					+ "</td></tr><tr><td>ENGINEERING GRAPHICS</td><td>" + u.getEg()
					+ "</td></tr><tr><td>COMMUNICATION ENGLISH</td><td>" + u.getCe()
					+ "</td></tr><tr><td>ENVIRONMENTAL SCIENCE</td><td>" + u.getEs()
					+ "</td></tr><tr><td>TOTAL MARKS</td><td>" + u.getTm()
					+ "</td></tr><tr><td>PERCENTAGE</td><td>" + u.getPer()
					+ "</td></tr><tr><td>RESULTS</td><td>" + u.getRe() + "</td></tr><tr>");
		
			out.print("</table>");
			out.print("</div>");
			out.close();
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("grregisterationerror.jsp");
		    }
	}

}
