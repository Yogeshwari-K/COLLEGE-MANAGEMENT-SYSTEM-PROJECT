package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/editsal1")
public class editsal1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String year = request.getParameter("year");
		double dir= Double.parseDouble(request.getParameter("dir"));
		double pri= Double.parseDouble(request.getParameter("pri"));
		double ad= Double.parseDouble(request.getParameter("ad"));
		double hod=Double.parseDouble(request.getParameter("hod"));
		double prof= Double.parseDouble(request.getParameter("prof"));
		double aprof= Double.parseDouble(request.getParameter("aprof"));
		double off= Double.parseDouble(request.getParameter("off"));
	
	
		SaUser e = new SaUser();
	 
		e.setDir(dir);
		e.setPri(pri);
		e.setAd(ad);
		e.setHod(hod);
		e.setProf(prof);
		e.setAprof(aprof);
		e.setOff(off);

		int status = SaUserdatabase.saupdate(e);
		if (status > 0) {
			response.sendRedirect("salaryStructure");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
