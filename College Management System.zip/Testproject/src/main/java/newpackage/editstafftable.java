package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editstafftable")
public class editstafftable extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Details</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		SUser e = SUserdatabase.sgetEmployeeById(id);
		out.print("<form action='editstafftable1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>"); 
		out.print("<tr><td>Degree:</td><td><input type='text' name='degree' value='"+e.getDegree()+"'/></td></tr>"); 
		out.print("<tr><td>Dep:</td><td><input type='text' name='dep' value='" + e.getDep() + "'/></td></tr>");
		out.print("<tr><td>Sem:</td><td><input type='text' name='sem' value='" + e.getSem()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Day:</td><td><input type='text' name='day' value='" + e.getDay() + "'/></td></tr>");
		out.print("<tr><td>I Period:</td><td><input type='text' name='first' value='" + e.getFirst() + "'/></td></tr>");
		out.print("<tr><td>II Period:</td><td><input type='text' name='second' value='" + e.getSecond() + "'/></td></tr>");
		out.print("<tr><td>III Period:</td><td><input type='text' name='third' value='" + e.getThird() + "'/></td></tr>");
		out.print("<tr><td>IV Period:</td><td><input type='text' name='fourth' value='" + e.getFourth() + "'/></td></tr>");
		out.print("<tr><td>Break:</td><td><input type='text' name='bre' value='" + e.getBre() + "'/></td></tr>");
		
		out.print("<tr><td>V Period:</td><td><input type='text' name='fifth' value='" + e.getFifth() + "'/></td></tr>");
		out.print("<tr><td>VI Period:</td><td><input type='text' name='sixth' value='" + e.getSixth() + "'/></td></tr>");
		out.print("<tr><td>VII Period:</td><td><input type='text' name='seventh' value='" + e.getSeventh() + "'/></td></tr>");
		
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
	}


}
