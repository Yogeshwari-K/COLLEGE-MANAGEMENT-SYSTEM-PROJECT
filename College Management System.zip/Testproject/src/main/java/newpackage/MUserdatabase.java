package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MUserdatabase {
	Connection con ;
    public MUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(MUser muser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into marks(Name,Degree,Dep,Sem,Sub,outof,scored) values(?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, muser.getName());
           pt.setString(2, muser.getDegree());
           pt.setString(3, muser.getDep());
           pt.setString(4, muser.getSem());
           pt.setString(5,muser.getSub());
           pt.setString(6, muser.getOutof());
           pt.setString(7,muser.getSmark());
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int mupdate(MUser e) {
		int status = 0;
		try {
			Connection con = FeUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update marks set Name=?,Degree=?,Dep=?,Sem=?,Sub=?,outof=?,scored=? where Id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getName());
			ps.setString(2, e.getDegree());
			ps.setString(3,e.getDep() );
			ps.setString(4,e.getSem() );
			ps.setString(5, e.getSub());
			ps.setString(6, e.getOutof());
			ps.setString(7,e.getSmark() );
			ps.setInt(8, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int mdelete(int id){  
        int status=0;  
        try{  
            Connection con=SaUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from marks where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  MUser mgetEmployeeById(int id) {
		MUser u = new MUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from marks where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setSem(rs.getString(5));
				u.setSub(rs.getString(6));
				u.setOutof(rs.getString(7));
				u.setSmark(rs.getString(8));
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<MUser> getAllEmployees() {
		List<MUser> list = new ArrayList<MUser>();

		try {
			Connection con = FeUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from marks");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				MUser u = new MUser(); 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setSem(rs.getString(5));
				u.setSub(rs.getString(6));
				u.setOutof(rs.getString(7));
				u.setSmark(rs.getString(8));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
    
    public static  MUser saget() {
		MUser u = new MUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from smarks";
            PreparedStatement pst = con.prepareStatement(query);
			
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setSem(rs.getString(5));
				u.setSub(rs.getString(6));
				u.setOutof(rs.getString(7));
				u.setSmark(rs.getString(8));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
}
    public static MUser get(String username) {
		MUser u = new MUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from marks where Name=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDegree(rs.getString(3));
				u.setDep(rs.getString(4));
				u.setSem(rs.getString(5));
				u.setSub(rs.getString(6));
				u.setOutof(rs.getString(7));
				u.setSmark(rs.getString(8));
				
				
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return u;
	}
}