package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// fetch data from login form
          try(PrintWriter out=response.getWriter()){
		String username= request.getParameter("username");
		String logpass = request.getParameter("password");

		UserDatabase db = new UserDatabase(ConnectionPro.getConnection());
		User user = db.logUser(username, logpass);

		if (user != null) {

			HttpSession session = request.getSession();
			session.setAttribute("loguser", user);
			response.sendRedirect("studentdash.jsp");
			
		} else {
			
			response.sendRedirect("usernotfound.html");
		}
}catch(Exception e)
{
	e.printStackTrace();
}
	}
}

