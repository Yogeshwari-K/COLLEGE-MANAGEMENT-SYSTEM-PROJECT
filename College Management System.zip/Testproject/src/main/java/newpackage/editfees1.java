package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editfees1")
public class editfees1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String year = request.getParameter("year");
		String tution = request.getParameter("tution");
		String  place= request.getParameter("place");
		String hostel=request.getParameter("hostel");
		String mess = request.getParameter("mess");
		String other = request.getParameter("other");
		String total1=request.getParameter("total");
	String totalh1=request.getParameter("totalh");
	double total=Double.parseDouble(total1);
	double totalh=Double.parseDouble(totalh1);

		FeUser e = new FeUser();
		e.setId(id);
		e.setYear(year);
		e.setTution(tution);
		e.setPlace(place);
		e.setHostel(hostel);
		e.setMess(mess);
		e.setOther(other);
		e.setTotal(total);
		e.setTotalh(totalh);

		int status = FeUserdatabase.feupdate(e);
		if (status > 0) {
			response.sendRedirect("feesStructure");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

}
