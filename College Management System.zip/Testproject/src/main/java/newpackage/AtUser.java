package newpackage;

public class AtUser {
	
private int id;
private String date, name,degree,dep,sem,attend,si;
public AtUser()
{

}
public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getDep() {
		return dep;
	}
	public void setDep(String dep) {
		this.dep = dep;
	}
	public String getSem() {
		return sem;
	}
	public void setSem(String sem) {
		this.sem = sem;
	}
	public String getAttend() {
		return attend;
	}
	public void setAttend(String attend) {
		this.attend = attend;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
public AtUser(String date,String name, String degree, String dep, String sem, String attend, String si) {
		super();
		this.date=date;
		this.name = name;
		this.degree = degree;
		this.dep = dep;
		this.sem = sem;
		this.attend = attend;
		this.si = si;
}

public AtUser(int id, String date,String name, String degree, String dep, String sem, String attend, String si) {
	super();
	this.id = id;
	this.date=date;
	this.name = name;
	this.degree = degree;
	this.dep = dep;
	this.sem = sem;
	this.attend = attend;
	this.si = si;
}
public AtUser(String name)
{
	super();
	this.name=name;
}
}
