package newpackage;

public class MUser {
private int id;
private String name,degree,dep,sem,sub,outof,smark;
public MUser()
{
	
}
public MUser(String name, String degree, String dep, String sem, String sub, String outof, String smark) {
	super();
	this.name = name;
	this.degree = degree;
	this.dep = dep;
	this.sem = sem;
	this.sub = sub;
	this.outof = outof;
	this.smark = smark;
}
public MUser(int id, String name, String degree, String dep, String sem, String sub, String outof, String smark) {
	super();
	this.id = id;
	this.name = name;
	this.degree = degree;
	this.dep = dep;
	this.sem = sem;
	this.sub = sub;
	this.outof = outof;
	this.smark = smark;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDegree() {
	return degree;
}
public void setDegree(String degree) {
	this.degree = degree;
}
public String getDep() {
	return dep;
}
public void setDep(String dep) {
	this.dep = dep;
}
public String getSem() {
	return sem;
}
public void setSem(String sem) {
	this.sem = sem;
}
public String getSub() {
	return sub;
}
public void setSub(String sub) {
	this.sub = sub;
}
public String getOutof() {
	return outof;
}
public void setOutof(String outof) {
	this.outof = outof;
}
public String getSmark() {
	return smark;
}
public void setSmark(String smark) {
	this.smark = smark;
}

}
