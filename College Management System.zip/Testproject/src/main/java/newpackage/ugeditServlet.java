package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ugeditServlet")
public class ugeditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Details</h1>");
		String sid = request.getParameter("id");
		int id=Integer.parseInt(sid);
		UgUser e = UgUserdatabase.getEmployeeById(id);
		out.print("<form action='ugeditServlet1' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");  
		out.print("<tr><td>Full Name:</td><td><input type='text' name='fname' value='" + e.getFname() + "'/></td></tr>");
		out.print("<tr><td>Last Name:</td><td><input type='text' name='lname' value='" + e.getLname()
				+ "'/>  </td></tr>");
		out.print("<tr><td>Date of Birth:</td><td><input type='text' name='dob' value='" + e.getDob() + "'/></td></tr>");
		out.print("<tr><td>Gender:</td><td><input type='text' name='gender' value='" + e.getGender() + "'/></td></tr>");
		out.print("<tr><td>HSC %:</td><td><input type='text' name='hscp' value='" + e.getHscp() + "'/></td></tr>");
		out.print("<tr><td>SSLC %:</td><td><input type='text' name='sslcp' value='" + e.getSslcp() + "'/></td></tr>");
		
		out.print("<tr><td>Degree:</td><td><input type='text' name='degree' value='" + e.getDegree() + "'/></td></tr>");
		out.print("<tr><td>Department:</td><td><input type='text' name='dep' value='" + e.getDep() + "'/></td></tr>");
		out.print("<tr><td>Email:</td><td><input type='text' name='email' value='" + e.getEmail() + "'/></td></tr>");
		out.print("<tr><td>Phone:</td><td><input type='text' name='phone' value='" + e.getPhone() + "'/></td></tr>");
		out.print("<tr><td>HSC Group:</td><td><input type='text' name='hscg' value='" + e.getHscg() + "'/></td></tr>");
		out.print("<tr><td>City:</td><td><input type='text' name='city' value='" + e.getCity() + "'/></td></tr>");
		
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");

		out.close();
	}

	

}
