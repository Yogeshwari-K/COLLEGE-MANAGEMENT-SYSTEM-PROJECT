package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class fregisterServlet
 */
@WebServlet("/fregisterServlet")
public class fregisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String dob=request.getParameter("dob");
		String gender=request.getParameter("gender");
		String username=request.getParameter("username");
		String email = request.getParameter("email");
		String phone=request.getParameter("phone");
		String password=request.getParameter("password");
		FUser fuserModel = new FUser(name,dob,gender,username,email,phone, password);
		

		//create a database model
		FUserdatabase fregUser = new FUserdatabase(ConnectionPro.getConnection());
		if (fregUser.saveUser(fuserModel)) {
		   response.sendRedirect("facultylogin.html");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("registerationerrorjsp");
		    }
	}
	}


