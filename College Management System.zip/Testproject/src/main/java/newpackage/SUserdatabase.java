package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SUserdatabase {
	Connection con ;
    public SUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(SUser suser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into staffschedule(Year,Dep,Sem,Day,first,second,third,fourth,break,fifth,sixth,seventh) values(?,?,?,?,?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, suser.getDegree());
           pt.setString(2, suser.getDep());
           pt.setString(3,suser.getSem());
           pt.setString(4,suser.getDay());
           pt.setString(5,suser.getFirst()); 
           pt.setString(6,suser.getSecond());
           pt.setString(7, suser.getThird());
           pt.setString(8,suser.getFourth());
           pt.setString(9, suser.getBre());
           pt.setString( 10, suser.getFifth());
           
           pt.setString(11, suser.getSixth());
           pt.setString(12, suser.getSeventh());
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int supdate(SUser e) {
		int status = 0;
		try {
			Connection con = SUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update staffschedule set Year=?,Dep=?,Sem=?,Day=?,first=?,second=?,third=?,fourth=?,break=?,fifth=?,sixth=?,seventh=? where Id=?");
			
			
			ps.setString(1, e.getDegree());
			ps.setString(2, e.getDep());
			ps.setString(3,e.getSem());
			ps.setString(4, e.getDay());
			ps.setString(5, e.getFirst());
			ps.setString(6, e.getSecond());
			ps.setString(7, e.getThird());
			ps.setString(8, e.getFourth());
			ps.setString(9, e.getBre());
			ps.setString(10, e.getFifth());
			ps.setString(11, e.getSixth());
			ps.setString(12, e.getSeventh());
			ps.setInt(13, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int sdelete(int id){  
        int status=0;  
        try{  
            Connection con=CUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from staffschedule where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  SUser sgetEmployeeById(int id) {
		SUser u = new SUser();

		try {
			Connection con = SUserdatabase.getConnection();
			String query ="select * from staffschedule where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setDegree(rs.getString(2));
				u.setDep(rs.getString(3));
				u.setSem(rs.getString(4));
				u.setDay(rs.getString(5));
				u.setFirst(rs.getString(6));
				u.setSecond(rs.getString(7));
				u.setThird(rs.getString(8));
				u.setFourth(rs.getString(9));
				u.setBre(rs.getString(10));
				u.setFifth(rs.getString(11));
				u.setSixth(rs.getString(12));
				u.setSeventh(rs.getString(13));
				
				
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<SUser> getAllEmployees() {
		List<SUser> list = new ArrayList<SUser>();

		try {
			Connection con = WUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from staffschedule");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				SUser u = new SUser(); 
				u.setId(rs.getInt(1));
				u.setDegree(rs.getString(2));
				u.setDep(rs.getString(3));
				u.setSem(rs.getString(4));
				u.setDay(rs.getString(5));
				u.setFirst(rs.getString(6));
				u.setSecond(rs.getString(7));
				u.setThird(rs.getString(8));
				u.setFourth(rs.getString(9));
				u.setBre(rs.getString(10));
				u.setFifth(rs.getString(11));
				u.setSixth(rs.getString(12));
				u.setSeventh(rs.getString(13));
				
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
}