package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PUserdatabase {
	Connection con ;
    public PUserdatabase(Connection con) {
        this.con = con;
    } 
    public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(PUser puser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into placement(Reg_No,Name,Dob,Degree,Department,Batch,Cgpa,Company,Salary,Designation) values(?,?,?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, puser.getReg());
           pt.setString(2,puser.getName());
           pt.setString(3,puser.getDob());
           pt.setString(4, puser.getDegree());
           pt.setString(5, puser.getDep());
           pt.setString(6,puser.getYear());
           pt.setString(7, puser.getCgpa());
           pt.setString(8, puser.getCom());
           pt.setString(9, puser.getSal());
           pt.setString(10, puser.getDes());
          
           
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int pupdate(PUser e) {
		int status = 0;
		try {
			Connection con =ReUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update placement set Reg_No=?,Name=?,Dob=?,Degree=?,Department=?,Batch=?,Cgpa=?,Company=?,Salary=?,Designation=? where Id=?");
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getReg());
			ps.setString(2, e.getName());
			ps.setString(3, e.getDob());
			ps.setString(4, e.getDegree());
			ps.setString(5, e.getDep());
			ps.setString(6, e.getYear());	
			ps.setString(7,e.getCgpa());
			ps.setString(8, e.getCom());
			ps.setString(9, e.getSal());
			ps.setString(10, e.getDes());	
		ps.setInt(11, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int pdelete(int id){  
        int status=0;  
        try{  
            Connection con=ReUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from placement where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  PUser getEmployeeById(int id) {
		PUser u = new PUser();

		try {
			Connection con = ReUserdatabase.getConnection();
			String query ="select * from placement where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
                u.setReg(rs.getString(2));
                u.setName(rs.getString(3));
               u.setDob(rs.getString(4));
               u.setDegree(rs.getString(5));
                u.setDep(rs.getString(6));
               u.setYear(rs.getString(7));
                u.setCgpa(rs.getString(8));
                u.setCom(rs.getString(9));
                u.setSal(rs.getString(10));
                u.setDes(rs.getString(11));
                
                 
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    
    public static  List<PUser> getAllEmployees() {
		List<PUser> list = new ArrayList<PUser>();

		try {
			Connection con = PUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from placement");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				PUser u = new PUser(); 
				 u.setId(rs.getInt(1));  
				u.setReg(rs.getString(2));
				u.setName(rs.getString(3));
				u.setDob(rs.getString(4));
				u.setDegree(rs.getString(5));
				u.setDep(rs.getString(6));
				u.setYear(rs.getString(7));
				u.setCgpa(rs.getString(8));
				u.setCom(rs.getString(9));
				u.setSal(rs.getString(10));
				u.setDes(rs.getString(11));
				
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;

}
}