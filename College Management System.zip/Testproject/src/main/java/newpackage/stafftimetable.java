package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/stafftimetable")
public class stafftimetable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String degree = request.getParameter("degree");
		String dep=request.getParameter("dep");
		String sem=request.getParameter("sem");
		String day=request.getParameter("day");
		String first=request.getParameter("first");
		String second = request.getParameter("second");
		String third=request.getParameter("third");
		String fourth=request.getParameter("fourth");
		String bre=request.getParameter("bre");
		String fifth=request.getParameter("fifth");
		String sixth=request.getParameter("sixth");
		String seventh=request.getParameter("seventh");
		SUser userModel = new SUser(degree,dep,sem,day,first,second,third,fourth,bre,fifth,sixth,seventh);
		

		//create a database model
		SUserdatabase regUser = new SUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
		   response.sendRedirect("staffindex.jsp");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("sregisterationerror.html");
		    }
	}

}
