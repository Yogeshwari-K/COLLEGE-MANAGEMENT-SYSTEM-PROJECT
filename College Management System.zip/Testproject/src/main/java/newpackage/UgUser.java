package newpackage;

public class UgUser {
	private int id;
private String fname,lname,dob,gender,hscp,sslcp,degree,dep,email,phone,hscg,city;
public UgUser()
{
	
}
public UgUser(int id, String fname,String lname, String dob, String gender, String hscp, String sslcp, String degree, String dep,
		String email, String phone, String city) {
	super();
	this.id = id;
	this.fname=fname;
	this.lname = lname;
	this.dob = dob;
	this.gender = gender;
	this.hscp = hscp;
	this.sslcp = sslcp;
	this.degree = degree;
	this.dep = dep;
	this.email = email;
	this.phone = phone;
	this.city = city;
}
public UgUser(String fname, String lname, String dob, String gender, String hscp, String sslcp, String degree,
		String dep, String email, String phone, String hscg, String city) {
	super();
	this.fname = fname;
	this.lname = lname;
	this.dob = dob;
	this.gender = gender;
	this.hscp = hscp;
	this.sslcp = sslcp;
	this.degree = degree;
	this.dep = dep;
	this.email = email;
	this.phone = phone;
	this.hscg = hscg;
	this.city = city;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getHscp() {
	return hscp;
}
public void setHscp(String hscp) {
	this.hscp = hscp;
}
public String getSslcp() {
	return sslcp;
}
public void setSslcp(String sslcp) {
	this.sslcp = sslcp;
}
public String getDegree() {
	return degree;
}
public void setDegree(String degree) {
	this.degree = degree;
}
public String getDep() {
	return dep;
}
public void setDep(String dep) {
	this.dep = dep;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getHscg() {
	return hscg;
}
public void setHscg(String hscg) {
	this.hscg = hscg;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

}
