package newpackage;

public class FeeUser {
private int id;
private String name,degree,dep,sem,hosteller;
private double tf,pd,ba;
public FeeUser()
{
	
}
public FeeUser(int id, String name, String degree, String dep, String sem, String hosteller, double tf, double pd,
		double ba) {
	super();
	this.id = id;
	this.name = name;
	this.degree = degree;
	this.dep = dep;
	this.sem = sem;
	this.hosteller = hosteller;
	this.tf = tf;
	this.pd = pd;
	this.ba = ba;
}
public FeeUser(String name, String degree, String dep, String sem, String hosteller, double tf, double pd,double ba) {
	super();
	this.name = name;
	this.degree = degree;
	this.dep = dep;
	this.sem = sem;
	this.hosteller = hosteller;
	this.tf = tf;
	this.pd = pd;
	this.ba = ba;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDegree() {
	return degree;
}
public void setDegree(String degree) {
	this.degree = degree;
}
public String getDep() {
	return dep;
}
public void setDep(String dep) {
	this.dep = dep;
}
public String getSem() {
	return sem;
}
public void setSem(String sem) {
	this.sem = sem;
}
public String getHosteller() {
	return hosteller;
}
public void setHosteller(String hosteller) {
	this.hosteller = hosteller;
}
public double getTf() {
	return tf;
}
public void setTf(double tf) {
	this.tf = tf;
}
public double getPd() {
	return pd;
}
public void setPd(double pd) {
	this.pd = pd;
}
public double getBa() {
	return ba;
}
public void setBa(double ba) {
	this.ba = ba;
}

}
