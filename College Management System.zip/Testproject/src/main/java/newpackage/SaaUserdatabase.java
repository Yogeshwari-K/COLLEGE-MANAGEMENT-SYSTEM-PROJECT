package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SaaUserdatabase {
	Connection con ;
    public SaaUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(SaaUser saauser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into salary(Name,Dob,Designation,Increment,Salary,Issued,Balance,Date_Of_Issuing) values(?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, saauser.getName());
           pt.setString(2,saauser.getDob());
           pt.setString(3,saauser.getDesig());
           pt.setDouble(4, saauser.getInc());
           pt.setDouble(5, saauser.getSal());
           pt.setDouble(6,saauser.getPd());
           pt.setDouble(7, saauser.getBa());
           pt.setString(8, saauser.getDate());
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int saaupdate(SaaUser e) {
		int status = 0;
		try {
			Connection con = SaaUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update salary set Name=?,Dob=?,Designation=?,Increment=?,Salary=?,Issued=?,Balance=?,Date_of_Issuing=? where id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getName());
			ps.setString(2, e.getDob());
			ps.setString(3, e.getDesig());
			ps.setDouble(4, e.getInc());
			ps.setDouble(5, e.getSal());
			ps.setDouble(6, e.getPd());	
			ps.setDouble(7, e.getBa());
			ps.setString(8, e.getDate());
			ps.setInt(9, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int saadelete(int id){  
        int status=0;  
        try{  
            Connection con=SaaUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from salary where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  SaaUser saagetEmployeeById(int id) {
		SaaUser u = new SaaUser();

		try {
			Connection con = SaaUserdatabase.getConnection();
			String query ="select * from salary where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setDesig(rs.getString(4));
				u.setInc(rs.getDouble(5));
				u.setSal(rs.getDouble(6));
				
				u.setPd(rs.getDouble(7));
				u.setBa(rs.getDouble(8));
				u.setDate(rs.getString(9));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<SaaUser> getAllEmployees() {
		List<SaaUser> list = new ArrayList<SaaUser>();

		try {
			Connection con = FacUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from salary");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				SaaUser u = new SaaUser(); 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setDesig(rs.getString(4));
			
				u.setInc(rs.getDouble(5));
				u.setSal(rs.getDouble(6));
				
				u.setPd(rs.getDouble(7));
				u.setBa(rs.getDouble(8));
				u.setDate(rs.getString(9));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}

    public static SaaUser get(String name) {
		SaaUser u = new SaaUser();

		try {
			Connection con = SaaUserdatabase.getConnection();
			String query ="select * from salary where Name=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, name);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setDesig(rs.getString(4));
				u.setInc(rs.getDouble(5));
				u.setSal(rs.getDouble(6));
				u.setPd(rs.getDouble(7));
				u.setBa(rs.getDouble(8));
				u.setDate(rs.getString(9));
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return u;
	}
}
