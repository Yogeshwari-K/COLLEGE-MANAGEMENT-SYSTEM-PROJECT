package newpackage;

public class FeUser {
private int id;
private String year,tution,place,hostel,mess,other;
private double total,totalh;
public FeUser()
{
	
}
public FeUser(double total,double totalh)
{
	this.total=total;
	this.totalh=totalh;
	
}
public FeUser(int id, String year, String tution, String place, String hostel, String mess, String other,double total,double totalh) {
	super();
	this.id = id;
	this.year = year;
	this.tution = tution;
	this.place = place;
	this.hostel = hostel;
	this.mess = mess;
	this.other = other;
	this.total=total;
	this.totalh=totalh;
}
public FeUser(String year, String tution, String place, String hostel, String mess, String other,double total,double totalh) {
	super();
	this.year = year;
	this.tution = tution;
	this.place = place;
	this.hostel = hostel;
	this.mess = mess;
	this.other = other;
	this.total=total;
	this.totalh=totalh;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getTution() {
	return tution;
}
public void setTution(String tution) {
	this.tution = tution;
}
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}
public String getHostel() {
	return hostel;
}
public void setHostel(String hostel) {
	this.hostel = hostel;
}
public String getMess() {
	return mess;
}
public void setMess(String mess) {
	this.mess = mess;
}
public String getOther() {
	return other;
}
public void setOther(String other) {
	this.other = other;
}
public double getTotal() {
	return total;
}
public void setTotal(double total) {
	this.total = total;
}
public double getTotalh() {
	return totalh;
}
public void setTotalh(double totalh) {
	this.totalh = totalh;
}

}
