package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/sviewtimetable")
public class sviewtimetable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<br>");
		out.println("<a href='studentdash.jsp'>back to Dashboard</a>");
		List<TUser> list = TUserdatabase.getAllEmployees();
		out.println("<div align='center'>");
		out.println("<h1>Time Table</h1>");
		
		out.print("<table border='1' width='70%'");
		out.print(
				"<tr><th>ID</th><th>SEMESTER</th><th>SUBJECT CODE </th><th>SUBJECT NAME</th><th>DATE</th><th>SESSION</th></tr>");
		for (TUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getSem() + "</td><td>" + u.getScode() + "</td><td>"
					+ u.getSname() + "</td><td>" + u.getDate() + "</td><td>" + u.getSess() 
					+ "</td></tr>");
		}
		out.print("</table>");

		out.close();
		out.print("</div>");
	}

}
