package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editstaffattend1")
public class editstaffattend1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String date=request.getParameter("date");
		String name = request.getParameter("name");
		
		String  dep= request.getParameter("dep");
	
		String attend = request.getParameter("attend");
		
       
      
		StaffUser e = new StaffUser();
		e.setId(id);
		e.setDate(date);
		e.setName(name);
		
		e.setDep(dep);
		
		e.setAttend(attend);
		
		int status = StaffUserdatabase.staffupdate(e);
		if (status > 0) {
			response.sendRedirect("viewstaffattendance");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
		
	}

}
