package newpackage;

import newpackage.FeUser;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addfeesdetails")
public class addfeesdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		String degree = request.getParameter("degree");
		String dep = request.getParameter("dep");
		String sem = request.getParameter("sem");
		String hosteller = request.getParameter("hosteller");
		String pd1 = request.getParameter("pd");
		FeUser u = FeUserdatabase.feget();
     
		double Total = u.getTotal();
	
		double Totalh =  u.getTotalh();
		double pd = Double.parseDouble(pd1);
		double tf = 0;
		double ba = 0;
		if (hosteller.equals("Yes")) {
			tf = Totalh;
			ba = (tf - pd);

		} else if (hosteller.equals("No")) {
			tf = Total;
			ba = (tf - pd);

		}

		FeeUser userModel = new FeeUser(name, degree, dep, sem, hosteller, tf, pd, ba);
		// create a database model
		FeeUserdatabase regUser = new FeeUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
			response.sendRedirect("feeindex.html");
		} else {
			String errorMessage = "User Available";
			HttpSession regSession = request.getSession();
			regSession.setAttribute("RegError", errorMessage);
			response.sendRedirect("feeregisterationerror.jsp");
		}
	}

}

/*
 * Double Total=Double.parseDouble(Total1); Double
 * Totalh=Double.parseDouble(Total2); Double pd1=Double.parseDouble(pd); String
 * tf = null; String ba = null; if(hosteller.equals("Yes")) { tf=Total2; Double
 * ba1=(Totalh-pd1); ba=Double.toString(ba1); } else if(hosteller.equals("No"))
 * { tf=Total1; Double ba1=(Total-pd1); ba=Double.toString(ba1); }
 */
/*
 * Float tution=Float.parseFloat(tution1); Float place=Float.parseFloat(place1);
 * Float hostel=Float.parseFloat(hostel1); Float mess=Float.parseFloat(mess1);
 * Float other=Float.parseFloat(other1); Float
 * tf1=(tution+place+hostel+mess+other); String tf=Float.toString(tf1); Float
 * pd1=Float.parseFloat(pd); float ba1=(tf1-pd1); String ba=Float.toString(ba1);
 */

/*
 * String ba = null; String tf = null; if(hosteller.equals("Yes")) {
 * tf="215000"; double pd1=Float.parseFloat(pd); double tf1=215000.0; double
 * ba1=(tf1-pd1); ba=Double.toString(ba1); } elseif(hosteller.equals("No")); {
 * tf="145000"; double tf1=145000; double pd1=Float.parseFloat(pd); double
 * ba1=(tf1-pd1); ba=Double.toString(ba1); }
 */
