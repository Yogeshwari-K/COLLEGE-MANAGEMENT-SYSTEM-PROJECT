package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/getplacementServlet")
public class getplacementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String reg=request.getParameter("reg");
		String name = request.getParameter("name");
		String dob = request.getParameter("dob");
		
		String degree=request.getParameter("degree");
		String dep=request.getParameter("dep");
		String year=request.getParameter("year");
		String cgpa=request.getParameter("cgpa");
		String com=request.getParameter("com");
		String sal=request.getParameter("sal");
		String des=request.getParameter("des");
		System.out.println(reg);
		PUser puser=new PUser(reg,name,dob,degree,dep,year,cgpa,com,sal,des);

				//create a database model
				PUserdatabase pregUser = new PUserdatabase(ConnectionPro.getConnection());
				if (pregUser.saveUser(puser)) {
				   response.sendRedirect("pindex.jsp");
				} else {
				    String errorMessage = "User Available";
				    HttpSession regSession = request.getSession();
				    regSession.setAttribute("RegError", errorMessage);
				    response.sendRedirect("registerationerror.jsp");
				    }
				
		
	}


	private PUser PUser(String reg, String name, String dob, String degree, String dep, String year, String cgpa,
			String com, String sal, String des) {
		// TODO Auto-generated method stub
		return null;
	}

}
