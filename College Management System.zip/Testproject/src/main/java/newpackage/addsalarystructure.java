package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addsalarystructure")
public class addsalarystructure extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String year = request.getParameter("year");
		double dir= Double.parseDouble(request.getParameter("dir"));
		double pri= Double.parseDouble(request.getParameter("pri"));
		double ad= Double.parseDouble(request.getParameter("ad"));
		double hod=Double.parseDouble(request.getParameter("hod"));
		double prof= Double.parseDouble(request.getParameter("prof"));
		double aprof= Double.parseDouble(request.getParameter("aprof"));
		double off= Double.parseDouble(request.getParameter("off"));
		SaUser userModel = new SaUser(year,dir,pri,ad,hod,prof,aprof,off);
		

		//create a database model
		SaUserdatabase regUser = new SaUserdatabase(ConnectionPro.getConnection());
		if (regUser.saveUser(userModel)) {
		   response.sendRedirect("saindex.jsp");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("saregisterationerror.html");
		    }
	}

}
