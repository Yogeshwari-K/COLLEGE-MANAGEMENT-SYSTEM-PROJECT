package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SaUserdatabase {
	Connection con ;
    public SaUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(SaUser sauser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into salStructure(year,Director,Principal,Ao,Hod,Prof,Aprof,office) values(?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, sauser.getYear());
           pt.setDouble(2,sauser.getDir());
           pt.setDouble(3,sauser.getPri());
           pt.setDouble(4, sauser.getAd());
           pt.setDouble(5, sauser.getHod());
           pt.setDouble(6,sauser.getProf());
           pt.setDouble(7, sauser.getAprof());
           pt.setDouble(8,sauser.getOff());
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int saupdate(SaUser e) {
		int status = 0;
		try {
			Connection con = FeUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update salStructure set year=?,Director=?,Principal=?,Ao=?,Hod=?,Prof=?,Aprof=?,Off=? where Id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getYear());
			ps.setDouble(2, e.getDir());
			ps.setDouble(3, e.getPri());
			ps.setDouble(4, e.getAd());
			ps.setDouble(5, e.getHod());
			ps.setDouble(6, e.getProf());	
			ps.setDouble(7, e.getAprof());
			ps.setDouble(8,e.getOff());
			ps.setInt(9, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int sadelete(int id){  
        int status=0;  
        try{  
            Connection con=SaUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from salStructure where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  SaUser sagetEmployeeById(int id) {
		SaUser u = new SaUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from salStructure where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setYear(rs.getString(2));
				u.setDir(rs.getDouble(3));
				u.setPri(rs.getDouble(4));
				u.setAd(rs.getDouble(5));
				u.setHod(rs.getDouble(6));
				u.setProf(rs.getDouble(7));
				u.setAprof(rs.getDouble(8));
				u.setOff(rs.getDouble(9));
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<SaUser> getAllEmployees() {
		List<SaUser> list = new ArrayList<SaUser>();

		try {
			Connection con = FeUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from salStructure");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				SaUser u = new SaUser(); 
				u.setId(rs.getInt(1));
				u.setYear(rs.getString(2));
				u.setDir(rs.getDouble(3));
				u.setPri(rs.getDouble(4));
				u.setAd(rs.getDouble(5));
				u.setHod(rs.getDouble(6));
				u.setProf(rs.getDouble(7));
				u.setAprof(rs.getDouble(8));
				u.setOff(rs.getDouble(9));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
    
    public static  SaUser saget() {
		SaUser u = new SaUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from salStructure ";
            PreparedStatement pst = con.prepareStatement(query);
			
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setYear(rs.getString(2));
				u.setDir(rs.getDouble(3));
				u.setPri(rs.getDouble(4));
				u.setAd(rs.getDouble(5));
				u.setHod(rs.getDouble(6));
				u.setProf(rs.getDouble(7));
				u.setAprof(rs.getDouble(8));
				u.setOff(rs.getDouble(9));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
}}
