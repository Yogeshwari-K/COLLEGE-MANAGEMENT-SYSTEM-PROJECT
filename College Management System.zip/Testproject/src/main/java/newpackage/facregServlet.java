package newpackage;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/facregServlet")
public class facregServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String dob=request.getParameter("dob");
		String gender=request.getParameter("gender");
		String quali=request.getParameter("quali");
		String spec= request.getParameter("spec");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String college=request.getParameter("college");
		String city=request.getParameter("city");
		FacUser facuserModel = new FacUser(name,dob,gender,quali,spec,email,phone,college,city);
		//create a database model
		FacUserdatabase facregUser = new FacUserdatabase(ConnectionPro.getConnection());
		if (facregUser.facsaveUser(facuserModel)) {
		   response.sendRedirect("facregsuccess.jsp");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("registerationerrorjsp");
		    }
	}
	}


