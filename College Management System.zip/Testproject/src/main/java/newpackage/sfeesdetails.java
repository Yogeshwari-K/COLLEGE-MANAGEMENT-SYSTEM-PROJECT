package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/sfeesdetails")
public class sfeesdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<a href='sindex.html'>back</a>");
		out.println("<br><br>");
		out.println("<a href='staffdash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Fees List</h1>");
		List<FeeUser> list = FeeUserdatabase.getAllEmployees();
		out.print("<table border='1' width='70%'");
		out.print(
				"<tr><th>ID</th><th>NAME</th><th>DEGREE</th><th>DEPARTMENT</th><th>SEMESTER</th><th>HOSTELLER</th><th>TOTAL FEES</th><th>PAID</th><th>BALANCE</th></tr>");
		for (FeeUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDegree() + "</td><td>"
					+ u.getDep() + "</td><td>" + u.getSem() + "</td><td>" + u.getHosteller() + "</td><td>" + u.getTf()+ "</td><td>" + u.getPd()+ "</td><td>" + u.getBa()
					+ "</td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}

	

}
