package newpackage;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/adminloginServlet")
public class adminloginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try(PrintWriter out=response.getWriter()){
			String alogname= request.getParameter("name");
			String alogpass = request.getParameter("password");
             
			AUserdatabase adb = new AUserdatabase(ConnectionPro.getConnection());
			AUser auser = adb.alogUser(alogname, alogpass);

			if (auser != null) {
				HttpSession session= request.getSession();
				session.setAttribute("alogUser",auser);
				response.sendRedirect("admindash.jsp");
			} else {
				
				response.sendRedirect("ausernotfound.jsp");
			}
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	}

}
