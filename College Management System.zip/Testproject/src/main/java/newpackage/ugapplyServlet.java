package newpackage;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class ugapplyServlet
 */
@WebServlet("/ugapplyServlet")
public class ugapplyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String dob=request.getParameter("dob");
		String gender=request.getParameter("gender");
		String hscp=request.getParameter("hscp");
		String sslcp=request.getParameter("sslcp");
		String degree = request.getParameter("degree");
		String dep = request.getParameter("dep");
		String email = request.getParameter("email");
		String phone=request.getParameter("phone");
		String hscg=request.getParameter("hscg");
		String city=request.getParameter("city");
UgUser uguserModel = new UgUser(fname,lname,dob,gender,hscp,sslcp,degree,dep,email,phone,hscg,city);
		

		//create a database model
		UgUserdatabase ugregUser = new UgUserdatabase(ConnectionPro.getConnection());
		if (ugregUser.saveUser(uguserModel)) {
		   response.sendRedirect("ugindex.jsp");
		} else {
		    String errorMessage = "User Available";
		    HttpSession regSession = request.getSession();
		    regSession.setAttribute("RegError", errorMessage);
		    response.sendRedirect("ugregistrationerror.jsp");
		    }
	}

		
	}


