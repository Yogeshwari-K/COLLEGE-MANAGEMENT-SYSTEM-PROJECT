package newpackage;

public class SaUser {
private int id;
private String year;
private double dir,pri,ad,hod,prof,aprof,off;
public SaUser()
{
	
}
public SaUser(int id, String year, double dir, double pri, double ad, double hod, double prof, double aprof,
		double off) {
	super();
	this.id = id;
	this.year = year;
	this.dir = dir;
	this.pri = pri;
	this.ad = ad;
	this.hod = hod;
	this.prof = prof;
	this.aprof = aprof;
	this.off = off;
}
public SaUser(String year, double dir, double pri, double ad, double hod, double prof, double aprof, double off) {
	super();
	this.year = year;
	this.dir = dir;
	this.pri = pri;
	this.ad = ad;
	this.hod = hod;
	this.prof = prof;
	this.aprof = aprof;
	this.off = off;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public double getDir() {
	return dir;
}
public void setDir(double dir) {
	this.dir = dir;
}
public double getPri() {
	return pri;
}
public void setPri(double pri) {
	this.pri = pri;
}
public double getAd() {
	return ad;
}
public void setAd(double ad) {
	this.ad = ad;
}
public double getHod() {
	return hod;
}
public void setHod(double hod) {
	this.hod = hod;
}
public double getProf() {
	return prof;
}
public void setProf(double prof) {
	this.prof = prof;
}
public double getAprof() {
	return aprof;
}
public void setAprof(double aprof) {
	this.aprof = aprof;
}
public double getOff() {
	return off;
}
public void setOff(double off) {
	this.off = off;
}

}
