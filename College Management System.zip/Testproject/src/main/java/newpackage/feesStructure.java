package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/feesStructure")
public class feesStructure extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<a href='addfees.jsp'>Add Details</a>");
		out.println("<br>");
		out.println("<a href='admindash.jsp'>back to Dashboard</a>");
		out.println("<div align='center'>");
		out.println("<h1>Fees Structure</h1>");
		List<FeUser> list = FeUserdatabase.getAllEmployees();
		out.print("<table border='1' width='70%'");
		out.print(
				"<tr><th>ID</th><th>YEAR</th><th>TUTION FEES</th><th>PLACEMENT FEES</th><th>HOSTEL FEES</th><th>MESS FEES</th><th>OTHER FEES</th><th>TOTAL FEES(NON-HOSTELLER)</th><th>TOTAL FEES(HOSTELLER)</th><th>EDIT</th><th>DELETE</th></tr>");
		for (FeUser u: list) {
			out.print("</td><td>" + u.getId() + "</td><td>" + u.getYear() + "</td><td>" + u.getTution() + "</td><td>"
					+ u.getPlace() + "</td><td>" + u.getHostel() + "</td><td>" + u.getMess() + "</td><td>" + u.getOther()+ "</td><td>" + u.getTotal()+ "</td><td>" + u.getTotalh()
					+"</td><td><a href='editfees?id=" + u.getId()+ "'>edit</a></td><td><a href='deleteFees?id=" + u.getId()+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}

	

}
