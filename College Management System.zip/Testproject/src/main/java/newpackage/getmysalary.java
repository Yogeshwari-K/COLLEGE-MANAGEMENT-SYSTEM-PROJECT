package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/getmysalary")
public class getmysalary extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		FUser fuser =  (FUser) session.getAttribute("flogUser");
		//System.out.println(fuser);
		String name1 = fuser.getName();
		//System.out.println(name1);
		SaaUser u = SaaUserdatabase.get(name1);
		out.println("<a href='studentdash.jsp'>Back to Dashboard</a>");
		if(u!=null)
		{
		out.println("<div align='center'>");
		out.println("<h1>Your Salary Details");
			out.print("<table border='1' width='80%'");
			out.print(
					"<tr><th>ID</th><th>NAME</th><th>DATE OF BIRTH</th><th>DESIGNATION</th><th>INCREMENT</th><th>SALARY</th><th>PAID</th><th>BALANCE</th><th>DATE OF ISSUING</th></tr>");

			out.print("</td><td>" + u.getId() + "</td><td>" + u.getName() + "</td><td>" + u.getDob() + "</td><td>"
					+ u.getDesig() + "</td><td>" + u.getInc() + "</td><td>" + u.getSal() + "</td><td>" + u.getPd()
					+ "</td><td>" + u.getBa() + "</td><td>" + u.getDate() + "</td></tr>");

			out.print("</table>");

			out.close();
			out.print("</div>");
		}
	else if(u==null)
	{
		out.println("No record Found.Will Update soon");
	}
}
			}
	


