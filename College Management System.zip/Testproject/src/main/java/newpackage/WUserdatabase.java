package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class WUserdatabase {
	Connection con ;
    public WUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    public boolean saveUser(WUser wuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into whours(Year,Date,Day,Workornot,Timing) values(?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, wuser.getYear());
           pt.setString(2,wuser.getDate());
           pt.setString(3,wuser.getDay());
           pt.setString(4,wuser.getWork()); 
           pt.setString(5,wuser.getTiming());
           
              
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public static int wupdate(WUser e) {
		int status = 0;
		try {
			Connection con = WUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update whours set Year=?,Date=?,Day=?,Workornot=?,Timing=? where Id=?");
			
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getYear());
			ps.setString(2,e.getDate());
			ps.setString(3, e.getDay());
			ps.setString(4, e.getWork());
			ps.setString(5, e.getTiming());
			ps.setInt(6, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int wdelete(int id){  
        int status=0;  
        try{  
            Connection con=WUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from whours where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  WUser wgetEmployeeById(int id) {
		WUser u = new WUser();

		try {
			Connection con = SaUserdatabase.getConnection();
			String query ="select * from whours where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setYear(rs.getString(2));
				u.setDate(rs.getString(3));
				u.setDay(rs.getString(4));
				u.setWork(rs.getString(5));
				u.setTiming(rs.getString(6));
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}
    public static  List<WUser> getAllEmployees() {
		List<WUser> list = new ArrayList<WUser>();

		try {
			Connection con = WUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from whours");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				WUser u = new WUser(); 
				u.setId(rs.getInt(1));
				u.setYear(rs.getString(2));
				u.setDate(rs.getString(3));
				u.setDay(rs.getString(4));
				u.setWork(rs.getString(5));
				u.setTiming(rs.getString(6));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
    
}
