package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDatabase {
	Connection con ;

    public UserDatabase(Connection con) {
        this.con = con;
    }
    public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    
    //for register user 
    public boolean saveUser(User user){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into user1(Name,Dob,Gender,Degree,Dep,Sem,Email,Phone,Username,password) values(?,?,?,?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, user.getName());
           pt.setString(2,user.getDob());
           pt.setString(3,user.getGender());
           
           pt.setString(4, user.getDegree());
           pt.setString(5, user.getDep());
           pt.setString(6, user.getSem());
           pt.setString(7, user.getEmail());
           pt.setString(8,user.getPhone());
           pt.setString(9, user.getUsername());
           pt.setString(10, user.getPassword());
           
           
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    //user login
  //user login
    public User logUser(String  name, String pass){
        User usr=null;
        try{
            String query ="select * from user1 where Username=? and password=?";
            PreparedStatement pst = this.con.prepareStatement(query);
            pst.setString(1, name);
            pst.setString(2, pass);
            
            ResultSet rs = pst.executeQuery();
            
            if(rs.next()){
                usr = new User();
                usr.setId(rs.getInt("id"));
                usr.setName(rs.getString("name"));
                usr.setDob(rs.getString("dob"));
                usr.setGender(rs.getString("gender"));
                
                usr.setDegree(rs.getString("degree"));
                usr.setDep(rs.getString("dep"));
                usr.setSem(rs.getString("sem"));
                usr.setEmail(rs.getString("email"));
                usr.setPhone(rs.getString("phone"));
                usr.setUsername(rs.getString("username"));
                usr.setPassword(rs.getString("password"));
             
                    
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return usr;
    }
    public static int update(User e) {
		int status = 0;
		try {
			Connection con = UserDatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update user1 set Name=?,Dob=?,Gender=?,Degree=?,Dep=?,Sem=?,Email=?,Phone=?,Username=?,password=? where Id=?");
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getName());
			ps.setString(2, e.getDob());
			ps.setString(3, e.getGender());
			ps.setString(4, e.getDegree());
			ps.setString(5, e.getDep());
			ps.setString(6, e.getSem());
			ps.setString(7, e.getEmail());
			ps.setString(8, e.getPhone());
			ps.setString(9, e.getUsername());
			ps.setString(10,e.getPassword());
			ps.setInt(11, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int delete(int id){  
        int status=0;  
        try{  
            Connection con=UserDatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from user1 where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  User getEmployeeById(int id) {
		User u = new User();

		try {
			Connection con = UserDatabase.getConnection();
			String query ="select * from user1 where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setGender(rs.getString(4));
				u.setDegree(rs.getString(5));
				u.setDep(rs.getString(6));
				u.setSem(rs.getString(7));
				u.setEmail(rs.getString(8));
				u.setPhone(rs.getString(9));
				u.setUsername(rs.getString(10));
				u.setPassword(rs.getString(11));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}

	public static  List<User> getAllEmployees() {
		List<User> list = new ArrayList<User>();

		try {
			Connection con = UserDatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from user1");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				User u = new User(); 
				 u.setId(rs.getInt(1));  
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setGender(rs.getString(4));
				u.setDegree(rs.getString(5));
				u.setDep(rs.getString(6));
				u.setSem(rs.getString(7));
				u.setEmail(rs.getString(8));
				u.setPhone(rs.getString(9));
				u.setUsername(rs.getString(10));
				u.setPassword(rs.getString(11));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	 public static User get(String username) {
			User u = new User();

			try {
				Connection con = UserDatabase.getConnection();
				String query ="select * from user1 where Name=?";
	            PreparedStatement pst = con.prepareStatement(query);
				pst.setString(1, username);
				ResultSet rs = pst.executeQuery();
				if (rs.next()) { 
					u.setId(rs.getInt(1));
					u.setName(rs.getString(2));
					u.setDob(rs.getString(3));
					u.setGender(rs.getString(4));
					u.setDegree(rs.getString(5));
					u.setDep(rs.getString(6));
					u.setSem(rs.getString(7));
					u.setEmail(rs.getString(8));
					u.setPhone(rs.getString(9));
					u.setUsername(rs.getString(10));
					u.setPassword(rs.getString(11));
					
					
					
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return u;
}

}