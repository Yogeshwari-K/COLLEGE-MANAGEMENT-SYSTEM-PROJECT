package newpackage;

public class WUser {
private int id;
private String year,date,day,work,Timing;
public WUser()
{
	
}
public WUser(int id, String year, String date, String day, String work, String timing) {
	super();
	this.id = id;
	this.year = year;
	this.date = date;
	this.day = day;
	this.work = work;
	Timing = timing;
}
public WUser(String year, String date, String day, String work, String timing) {
	super();
	this.year = year;
	this.date = date;
	this.day = day;
	this.work = work;
	Timing = timing;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getDay() {
	return day;
}
public void setDay(String day) {
	this.day = day;
}
public String getWork() {
	return work;
}
public void setWork(String work) {
	this.work = work;
}
public String getTiming() {
	return Timing;
}
public void setTiming(String timing) {
	Timing = timing;
}

}
