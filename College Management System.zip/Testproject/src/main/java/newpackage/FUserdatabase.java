package newpackage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FUserdatabase {
	Connection con ;
    public FUserdatabase(Connection con) {
        this.con = con;
    } public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "Yoga@12345");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
    
    //for register user 
    public boolean saveUser(FUser fuser){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into user2(name,dob,gender,username,email,phone,password) values(?,?,?,?,?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, fuser.getName());
           pt.setString(2,fuser.getDob());
           pt.setString(3,fuser.getGender());
           pt.setString(4, fuser.getUsername());
           pt.setString(5, fuser.getEmail());
           pt.setString(6,fuser.getPhone());
           pt.setString(7, fuser.getPassword());
           
           
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    //user login
    public FUser flogUser(String name, String pass){
        
    	FUser fusr=null;
        try{
            String query ="select * from user2 where Username=? and password=?";
            PreparedStatement fpst = this.con.prepareStatement(query);
            fpst.setString(1, name);
            fpst.setString(2, pass);
            
            ResultSet frs = fpst.executeQuery();
            
            if(frs.next()){
                fusr = new FUser();
                fusr.setId(frs.getInt("id"));
                fusr.setName(frs.getString("name"));
               fusr.setDob(frs.getString("dob"));
               fusr.setGender(frs.getString("gender"));
                fusr.setUsername(frs.getString("username"));
                fusr.setEmail(frs.getString("email"));
                fusr.setPhone(frs.getString("phone"));
                fusr.setPassword(frs.getString("password"));
             
                
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return fusr;
    }
    
    public static int fupdate(FUser e) {
		int status = 0;
		try {
			Connection con = FUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update user2 set Name=?,Dob=?,Gender=?,Username=?,Email=?,Phone=?,password=? where Id=?");
			//ps.setInt(1, e.getId());
			ps.setString(1, e.getName());
			ps.setString(2, e.getDob());
			ps.setString(3, e.getGender());
			ps.setString(4, e.getUsername());
			ps.setString(5, e.getEmail());
			ps.setString(6, e.getPhone());	
			ps.setString(7,e.getPassword());
			ps.setInt(8, e.getId());
			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}
    public static int fdelete(int id){  
        int status=0;  
        try{  
            Connection con=FUserdatabase.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from user2 where Id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception e)
        {e.printStackTrace();
        }  
          
        return status;  
    } 
    public static  FUser getEmployeeById(int id) {
		FUser u = new FUser();

		try {
			Connection con = FUserdatabase.getConnection();
			String query ="select * from user2 where Id=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setGender(rs.getString(4));
				u.setUsername(rs.getString(5));
				u.setEmail(rs.getString(6));
				u.setPhone(rs.getString(7));
				u.setPassword(rs.getString(8));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}

	public static  List<FUser> getAllEmployees() {
		List<FUser> list = new ArrayList<FUser>();

		try {
			Connection con = FUserdatabase.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from user2");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				FUser u = new FUser(); 
				 u.setId(rs.getInt(1));  
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setGender(rs.getString(4));
				u.setUsername(rs.getString(5));
				u.setEmail(rs.getString(6));
				u.setPhone(rs.getString(7));
				
				u.setPassword(rs.getString(8));
				list.add(u);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
}
	public static FUser get(String username) {
		FUser u = new FUser();

		try {
			Connection con = FUserdatabase.getConnection();
			String query ="select * from user2 where Name=?";
            PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { 
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setDob(rs.getString(3));
				u.setGender(rs.getString(4));
				u.setUsername(rs.getString(5));
				u.setEmail(rs.getString(6));
				u.setPhone(rs.getString(7));
				u.setPassword(rs.getString(8));
				
				
				
				
				
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return u;
}}
