package newpackage;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editwork1")
public class editwork1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String year = request.getParameter("year");
		String date = request.getParameter("date");
		String  day= request.getParameter("day");
		String work=request.getParameter("work");
		String Timing = request.getParameter("Timing");
		
		WUser e = new WUser();
		e.setId(id);
		e.setYear(year);
		e.setDate(date);
		e.setDay(day);
		e.setWork(work);
		e.setTiming(Timing);
		

		int status = WUserdatabase.wupdate(e);
		if (status > 0) {
			response.sendRedirect("viewworking");
		} else {
			out.println("Sorry! unable to update record");
		}

		out.close();
	}

	

}
